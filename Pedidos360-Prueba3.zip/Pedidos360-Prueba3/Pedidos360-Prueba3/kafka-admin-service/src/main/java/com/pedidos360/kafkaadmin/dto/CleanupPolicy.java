package com.pedidos360.kafkaadmin.dto;

/**
 * cleanup.policy de un topico:
 *  DELETE         borra segmentos antiguos segun retention.ms / retention.bytes
 *  COMPACT        conserva solo el ultimo valor de cada clave
 *  COMPACT_DELETE ambas: conserva el ultimo valor por clave y ademas borra lo que supere la retencion
 */
public enum CleanupPolicy {
    DELETE("delete"),
    COMPACT("compact"),
    COMPACT_DELETE("compact,delete");

    private final String kafkaValue;

    CleanupPolicy(String kafkaValue) {
        this.kafkaValue = kafkaValue;
    }

    public String kafkaValue() {
        return kafkaValue;
    }
}
