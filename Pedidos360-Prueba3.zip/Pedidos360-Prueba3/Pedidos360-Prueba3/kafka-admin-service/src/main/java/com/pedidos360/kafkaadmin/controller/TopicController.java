package com.pedidos360.kafkaadmin.controller;

import com.pedidos360.kafkaadmin.dto.ApiResponseDTO;
import com.pedidos360.kafkaadmin.dto.KafkaViews.TopicDetail;
import com.pedidos360.kafkaadmin.dto.KafkaViews.TopicOffsets;
import com.pedidos360.kafkaadmin.dto.KafkaViews.TopicSummary;
import com.pedidos360.kafkaadmin.dto.PartitionsRequest;
import com.pedidos360.kafkaadmin.dto.TopicConfigUpdateRequest;
import com.pedidos360.kafkaadmin.dto.TopicCreateRequest;
import com.pedidos360.kafkaadmin.service.KafkaAdminService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Recurso "topics":
 *   POST   /api/kafka/topics                      crea un topico (particiones, replicas, retencion, cleanup policy)
 *   GET    /api/kafka/topics                      lista topicos
 *   GET    /api/kafka/topics/{name}               detalle: particiones, lider, ISR y configuracion
 *   GET    /api/kafka/topics/{name}/offsets       offsets y mensajes por particion
 *   PUT    /api/kafka/topics/{name}/config        modifica (set) o restablece (reset) configuraciones
 *   PATCH  /api/kafka/topics/{name}/partitions    aumenta el numero de particiones
 *   DELETE /api/kafka/topics/{name}               elimina el topico (?force=true para los de negocio)
 */
@RestController
@RequestMapping("/api/kafka/topics")
@PreAuthorize("hasRole('ADMIN')")
public class TopicController {

    private final KafkaAdminService adminService;

    public TopicController(KafkaAdminService adminService) {
        this.adminService = adminService;
    }

    @PostMapping
    public ResponseEntity<ApiResponseDTO<TopicDetail>> create(@Valid @RequestBody TopicCreateRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(new ApiResponseDTO<>(
                true, HttpStatus.CREATED.value(), "Topico creado satisfactoriamente",
                adminService.createTopic(request), 1L));
    }

    @GetMapping
    public ResponseEntity<ApiResponseDTO<List<TopicSummary>>> list() {
        List<TopicSummary> topics = adminService.listTopics();
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Topicos obtenidos satisfactoriamente", topics, (long) topics.size()));
    }

    @GetMapping("/{name}")
    public ResponseEntity<ApiResponseDTO<TopicDetail>> get(@PathVariable String name) {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Topico encontrado", adminService.describeTopic(name), 1L));
    }

    @GetMapping("/{name}/offsets")
    public ResponseEntity<ApiResponseDTO<TopicOffsets>> offsets(@PathVariable String name) {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Offsets del topico", adminService.topicOffsets(name), 1L));
    }

    @PutMapping("/{name}/config")
    public ResponseEntity<ApiResponseDTO<TopicDetail>> updateConfig(@PathVariable String name,
                                                                    @Valid @RequestBody TopicConfigUpdateRequest request) {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Configuracion actualizada satisfactoriamente",
                adminService.updateTopicConfig(name, request), 1L));
    }

    @PatchMapping("/{name}/partitions")
    public ResponseEntity<ApiResponseDTO<TopicDetail>> increasePartitions(@PathVariable String name,
                                                                          @Valid @RequestBody PartitionsRequest request) {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Particiones aumentadas satisfactoriamente",
                adminService.increasePartitions(name, request.totalPartitions()), 1L));
    }

    @DeleteMapping("/{name}")
    public ResponseEntity<ApiResponseDTO<Object>> delete(@PathVariable String name,
                                                         @RequestParam(defaultValue = "false") boolean force) {
        adminService.deleteTopic(name, force);
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Topico eliminado satisfactoriamente", null, 1L));
    }
}
