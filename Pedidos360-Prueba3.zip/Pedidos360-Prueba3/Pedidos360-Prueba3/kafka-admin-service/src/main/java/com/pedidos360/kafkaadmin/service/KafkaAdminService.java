package com.pedidos360.kafkaadmin.service;

import com.pedidos360.kafkaadmin.config.KafkaAdminProperties;
import com.pedidos360.kafkaadmin.dto.KafkaViews.BrokerView;
import com.pedidos360.kafkaadmin.dto.KafkaViews.ClusterView;
import com.pedidos360.kafkaadmin.dto.KafkaViews.ConfigView;
import com.pedidos360.kafkaadmin.dto.KafkaViews.GroupDetail;
import com.pedidos360.kafkaadmin.dto.KafkaViews.GroupLag;
import com.pedidos360.kafkaadmin.dto.KafkaViews.GroupSummary;
import com.pedidos360.kafkaadmin.dto.KafkaViews.LagRow;
import com.pedidos360.kafkaadmin.dto.KafkaViews.MemberView;
import com.pedidos360.kafkaadmin.dto.KafkaViews.PartitionOffsets;
import com.pedidos360.kafkaadmin.dto.KafkaViews.PartitionView;
import com.pedidos360.kafkaadmin.dto.KafkaViews.TopicDetail;
import com.pedidos360.kafkaadmin.dto.KafkaViews.TopicOffsets;
import com.pedidos360.kafkaadmin.dto.KafkaViews.TopicSummary;
import com.pedidos360.kafkaadmin.dto.TopicConfigUpdateRequest;
import com.pedidos360.kafkaadmin.dto.TopicCreateRequest;
import com.pedidos360.kafkaadmin.exception.ConflictException;
import com.pedidos360.kafkaadmin.exception.KafkaOperationException;
import com.pedidos360.kafkaadmin.exception.KafkaUnavailableException;
import com.pedidos360.kafkaadmin.exception.NotFoundException;
import org.apache.kafka.clients.admin.Admin;
import org.apache.kafka.clients.admin.AlterConfigOp;
import org.apache.kafka.clients.admin.Config;
import org.apache.kafka.clients.admin.ConfigEntry;
import org.apache.kafka.clients.admin.ConsumerGroupDescription;
import org.apache.kafka.clients.admin.ConsumerGroupListing;
import org.apache.kafka.clients.admin.DescribeClusterResult;
import org.apache.kafka.clients.admin.ListOffsetsResult.ListOffsetsResultInfo;
import org.apache.kafka.clients.admin.ListTopicsOptions;
import org.apache.kafka.clients.admin.MemberDescription;
import org.apache.kafka.clients.admin.NewPartitions;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.admin.OffsetSpec;
import org.apache.kafka.clients.admin.TopicDescription;
import org.apache.kafka.clients.consumer.OffsetAndMetadata;
import org.apache.kafka.common.Node;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.TopicPartitionInfo;
import org.apache.kafka.common.config.ConfigResource;
import org.apache.kafka.common.errors.GroupIdNotFoundException;
import org.apache.kafka.common.errors.GroupNotEmptyException;
import org.apache.kafka.common.errors.InvalidConfigurationException;
import org.apache.kafka.common.errors.InvalidPartitionsException;
import org.apache.kafka.common.errors.InvalidReplicationFactorException;
import org.apache.kafka.common.errors.InvalidRequestException;
import org.apache.kafka.common.errors.InvalidTopicException;
import org.apache.kafka.common.errors.TopicExistsException;
import org.apache.kafka.common.errors.UnknownTopicOrPartitionException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeSet;
import java.util.concurrent.ExecutionException;
import java.util.regex.Pattern;

/**
 * UNICA clase que habla con Kafka (AdminClient). Los controladores solo llaman a estos metodos de alto nivel
 * y no conocen la libreria de Kafka. Aqui vive la logica de administracion:
 *  - topicos: crear, listar, describir, modificar configuraciones, aumentar particiones, eliminar, offsets
 *  - consumer groups: listar, describir (miembros y asignacion), calcular lag, eliminar
 *  - clúster: brokers y controlador
 * Los errores del cliente de Kafka se traducen a excepciones propias (404, 409, 400, 503, 502).
 */
@Service
public class KafkaAdminService {

    private static final Logger log = LoggerFactory.getLogger(KafkaAdminService.class);
    private static final Pattern VALID_NAME = Pattern.compile("^(?!__)(?!\\.{1,2}$)[A-Za-z0-9._-]{1,249}$");

    private final Admin admin;
    private final KafkaAdminProperties props;

    public KafkaAdminService(Admin admin, KafkaAdminProperties props) {
        this.admin = admin;
        this.props = props;
    }

    // ===================== TOPICOS =====================

    public TopicDetail createTopic(TopicCreateRequest request) {
        NewTopic newTopic = new NewTopic(request.name(), request.partitions(), request.replicationFactor().shortValue())
                .configs(request.toConfigMap());
        call("crear el topico " + request.name(), () -> admin.createTopics(List.of(newTopic)).all().get());
        log.info("Topico creado name={} particiones={} replicas={} configs={}",
                request.name(), request.partitions(), request.replicationFactor(), request.toConfigMap());
        return describeTopic(request.name());
    }

    public List<TopicSummary> listTopics() {
        Collection<String> names = call("listar topicos",
                () -> admin.listTopics(new ListTopicsOptions().listInternal(false)).names().get());
        if (names.isEmpty()) {
            return List.of();
        }
        Map<String, TopicDescription> descriptions = call("describir topicos",
                () -> admin.describeTopics(names).allTopicNames().get());
        return new TreeSet<>(names).stream()
                .map(n -> summarize(descriptions.get(n)))
                .toList();
    }

    public TopicDetail describeTopic(String name) {
        requireValidName(name);
        TopicDescription description = call("describir el topico " + name,
                () -> admin.describeTopics(List.of(name)).allTopicNames().get().get(name));
        ConfigResource resource = new ConfigResource(ConfigResource.Type.TOPIC, name);
        Config config = call("leer configuracion de " + name,
                () -> admin.describeConfigs(List.of(resource)).all().get().get(resource));

        List<PartitionView> partitions = description.partitions().stream()
                .sorted(Comparator.comparingInt(TopicPartitionInfo::partition))
                .map(p -> new PartitionView(
                        p.partition(),
                        p.leader() == null ? null : p.leader().id(),
                        p.replicas().stream().map(Node::id).toList(),
                        p.isr().stream().map(Node::id).toList()))
                .toList();
        List<ConfigView> configs = config.entries().stream()
                .sorted(Comparator.comparing(ConfigEntry::name))
                .map(e -> new ConfigView(e.name(), e.value(), String.valueOf(e.source())))
                .toList();
        return new TopicDetail(name, partitions.size(), replicationFactorOf(description), partitions, configs);
    }

    /** Modifica (set) o devuelve a su valor por defecto (reset) configuraciones de un topico. */
    public TopicDetail updateTopicConfig(String name, TopicConfigUpdateRequest request) {
        requireValidName(name);
        describeTopic(name); // 404 si no existe
        List<AlterConfigOp> ops = new ArrayList<>();
        if (request.set() != null) {
            request.set().forEach((k, v) ->
                    ops.add(new AlterConfigOp(new ConfigEntry(k, v), AlterConfigOp.OpType.SET)));
        }
        if (request.reset() != null) {
            request.reset().forEach(k ->
                    ops.add(new AlterConfigOp(new ConfigEntry(k, null), AlterConfigOp.OpType.DELETE)));
        }
        ConfigResource resource = new ConfigResource(ConfigResource.Type.TOPIC, name);
        Map<ConfigResource, Collection<AlterConfigOp>> changes = new HashMap<>();
        changes.put(resource, ops);
        call("modificar configuracion de " + name, () -> admin.incrementalAlterConfigs(changes).all().get());
        log.info("Configuracion de topico modificada name={} set={} reset={}", name, request.set(), request.reset());
        return describeTopic(name);
    }

    /** Kafka solo permite AUMENTAR el numero de particiones. */
    public TopicDetail increasePartitions(String name, int totalPartitions) {
        requireValidName(name);
        int current = describeTopic(name).partitions();
        if (totalPartitions <= current) {
            throw new IllegalArgumentException("El topico ya tiene " + current
                    + " particiones; Kafka solo permite aumentarlas (totalPartitions debe ser mayor)");
        }
        Map<String, NewPartitions> request = new HashMap<>();
        request.put(name, NewPartitions.increaseTo(totalPartitions));
        call("aumentar particiones de " + name, () -> admin.createPartitions(request).all().get());
        log.info("Particiones aumentadas topic={} {} -> {}", name, current, totalPartitions);
        return describeTopic(name);
    }

    public void deleteTopic(String name, boolean force) {
        requireValidName(name);
        if (props.protectedTopics().contains(name) && !force) {
            throw new ConflictException("'" + name + "' es un topico de negocio protegido. "
                    + "Para eliminarlo igualmente usa ?force=true");
        }
        call("eliminar el topico " + name, () -> admin.deleteTopics(List.of(name)).all().get());
        log.warn("Topico eliminado name={} force={}", name, force);
    }

    /** Offsets por particion: earliest, latest y cantidad de mensajes retenidos. */
    public TopicOffsets topicOffsets(String name) {
        requireValidName(name);
        TopicDescription description = call("describir el topico " + name,
                () -> admin.describeTopics(List.of(name)).allTopicNames().get().get(name));
        Map<TopicPartition, OffsetSpec> earliestReq = new HashMap<>();
        Map<TopicPartition, OffsetSpec> latestReq = new HashMap<>();
        for (TopicPartitionInfo p : description.partitions()) {
            TopicPartition tp = new TopicPartition(name, p.partition());
            earliestReq.put(tp, OffsetSpec.earliest());
            latestReq.put(tp, OffsetSpec.latest());
        }
        Map<TopicPartition, ListOffsetsResultInfo> earliest = call("leer offsets earliest",
                () -> admin.listOffsets(earliestReq).all().get());
        Map<TopicPartition, ListOffsetsResultInfo> latest = call("leer offsets latest",
                () -> admin.listOffsets(latestReq).all().get());

        List<PartitionOffsets> rows = new ArrayList<>();
        long total = 0;
        List<TopicPartition> ordered = earliest.keySet().stream()
                .sorted(Comparator.comparingInt(TopicPartition::partition)).toList();
        for (TopicPartition tp : ordered) {
            long from = earliest.get(tp).offset();
            long to = latest.get(tp).offset();
            rows.add(new PartitionOffsets(tp.partition(), from, to, to - from));
            total += to - from;
        }
        return new TopicOffsets(name, total, rows);
    }

    // ===================== CONSUMER GROUPS =====================

    public List<GroupSummary> listConsumerGroups() {
        Collection<ConsumerGroupListing> listings = call("listar consumer groups",
                () -> admin.listConsumerGroups().all().get());
        if (listings.isEmpty()) {
            return List.of();
        }
        List<String> ids = listings.stream().map(ConsumerGroupListing::groupId).sorted().toList();
        Map<String, ConsumerGroupDescription> descriptions = call("describir consumer groups",
                () -> admin.describeConsumerGroups(ids).all().get());
        return ids.stream()
                .map(id -> new GroupSummary(id, String.valueOf(descriptions.get(id).state()),
                        descriptions.get(id).members().size()))
                .toList();
    }

    public GroupDetail describeConsumerGroup(String groupId) {
        ConsumerGroupDescription d = describeGroupRaw(groupId);
        List<MemberView> members = d.members().stream()
                .map(m -> new MemberView(m.consumerId(), m.clientId(), m.host(), assignedPartitions(m)))
                .toList();
        String coordinator = d.coordinator() == null ? null : d.coordinator().host() + ":" + d.coordinator().port();
        return new GroupDetail(groupId, String.valueOf(d.state()), d.partitionAssignor(), coordinator, members);
    }

    /** lag = ultimo offset del topico (log end offset) - ultimo offset confirmado por el grupo. */
    public GroupLag consumerGroupLag(String groupId) {
        ConsumerGroupDescription description = describeGroupRaw(groupId);
        Map<TopicPartition, OffsetAndMetadata> committed = call("leer offsets del grupo " + groupId,
                () -> admin.listConsumerGroupOffsets(groupId).partitionsToOffsetAndMetadata().get());

        Map<TopicPartition, String> owners = new HashMap<>();
        for (MemberDescription m : description.members()) {
            for (TopicPartition tp : m.assignment().topicPartitions()) {
                owners.put(tp, m.consumerId());
            }
        }

        Map<TopicPartition, OffsetSpec> latestReq = new HashMap<>();
        committed.forEach((tp, meta) -> {
            if (meta != null) {
                latestReq.put(tp, OffsetSpec.latest());
            }
        });
        Map<TopicPartition, ListOffsetsResultInfo> latest = latestReq.isEmpty() ? Map.of()
                : call("leer offsets finales", () -> admin.listOffsets(latestReq).all().get());

        List<LagRow> rows = new ArrayList<>();
        long totalLag = 0;
        for (Map.Entry<TopicPartition, ListOffsetsResultInfo> e : latest.entrySet()) {
            TopicPartition tp = e.getKey();
            long current = committed.get(tp).offset();
            long end = e.getValue().offset();
            long lag = Math.max(0, end - current);
            totalLag += lag;
            rows.add(new LagRow(tp.topic(), tp.partition(), current, end, lag, owners.get(tp)));
        }
        rows.sort(Comparator.comparing(LagRow::topic).thenComparingInt(LagRow::partition));
        return new GroupLag(groupId, String.valueOf(description.state()), totalLag, rows);
    }

    /** Solo se puede eliminar un grupo SIN miembros activos. */
    public void deleteConsumerGroup(String groupId) {
        requireGroupId(groupId);
        call("eliminar el grupo " + groupId, () -> admin.deleteConsumerGroups(List.of(groupId)).all().get());
        log.warn("Consumer group eliminado groupId={}", groupId);
    }

    // ===================== CLUSTER =====================

    public ClusterView describeCluster() {
        DescribeClusterResult result = admin.describeCluster();
        String clusterId = call("describir el clúster", () -> result.clusterId().get());
        Node controller = call("obtener el controlador", () -> result.controller().get());
        Collection<Node> nodes = call("listar brokers", () -> result.nodes().get());
        List<BrokerView> brokers = nodes.stream()
                .sorted(Comparator.comparingInt(Node::id))
                .map(n -> new BrokerView(n.id(), n.host(), n.port(), n.rack(),
                        controller != null && controller.id() == n.id()))
                .toList();
        return new ClusterView(clusterId, brokers.size(), brokers);
    }

    // ===================== apoyo =====================

    private ConsumerGroupDescription describeGroupRaw(String groupId) {
        requireGroupId(groupId);
        ConsumerGroupDescription d = call("describir el grupo " + groupId,
                () -> admin.describeConsumerGroups(List.of(groupId)).all().get().get(groupId));
        // Kafka responde un grupo "Dead" y sin miembros cuando el grupo no existe
        if (d == null || "DEAD".equalsIgnoreCase(String.valueOf(d.state()))) {
            throw new NotFoundException("El consumer group '" + groupId + "' no existe");
        }
        return d;
    }

    private List<String> assignedPartitions(MemberDescription member) {
        return member.assignment().topicPartitions().stream()
                .sorted(Comparator.comparing(TopicPartition::topic).thenComparingInt(TopicPartition::partition))
                .map(tp -> tp.topic() + "-" + tp.partition())
                .toList();
    }

    private TopicSummary summarize(TopicDescription d) {
        return new TopicSummary(d.name(), d.partitions().size(), replicationFactorOf(d));
    }

    private int replicationFactorOf(TopicDescription d) {
        return d.partitions().isEmpty() ? 0 : d.partitions().get(0).replicas().size();
    }

    private void requireValidName(String name) {
        if (name == null || !VALID_NAME.matcher(name).matches()) {
            throw new IllegalArgumentException("Nombre de topico invalido: '" + name + "'");
        }
    }

    private void requireGroupId(String groupId) {
        if (groupId == null || groupId.isBlank() || groupId.length() > 255) {
            throw new IllegalArgumentException("groupId invalido");
        }
    }

    @FunctionalInterface
    private interface KafkaCall<T> {
        T run() throws Exception;
    }

    /** Ejecuta una llamada al AdminClient y traduce los errores de Kafka a excepciones propias. */
    private <T> T call(String operation, KafkaCall<T> action) {
        try {
            return action.run();
        } catch (InterruptedException ex) {
            Thread.currentThread().interrupt();
            throw new KafkaUnavailableException("Operacion interrumpida al " + operation, ex);
        } catch (ExecutionException ex) {
            throw translate(operation, ex.getCause() == null ? ex : ex.getCause());
        } catch (RuntimeException ex) {
            throw translate(operation, ex);
        } catch (Exception ex) {
            throw new KafkaOperationException("No se pudo " + operation + ": " + ex.getMessage(), ex);
        }
    }

    private RuntimeException translate(String operation, Throwable cause) {
        if (cause instanceof TopicExistsException) {
            return new ConflictException("El topico ya existe");
        }
        if (cause instanceof UnknownTopicOrPartitionException) {
            return new NotFoundException("El topico no existe");
        }
        if (cause instanceof GroupIdNotFoundException) {
            return new NotFoundException("El consumer group no existe");
        }
        if (cause instanceof GroupNotEmptyException) {
            return new ConflictException("El consumer group tiene miembros activos; detén los consumidores primero");
        }
        if (cause instanceof InvalidReplicationFactorException || cause instanceof InvalidPartitionsException
                || cause instanceof InvalidTopicException || cause instanceof InvalidConfigurationException
                || cause instanceof InvalidRequestException) {
            return new IllegalArgumentException("Kafka rechazo la peticion: " + cause.getMessage());
        }
        if (cause instanceof org.apache.kafka.common.errors.TimeoutException
                || cause instanceof java.util.concurrent.TimeoutException
                || cause instanceof org.apache.kafka.common.errors.DisconnectException) {
            return new KafkaUnavailableException("Kafka no responde al " + operation
                    + " (¿brokers caidos o bootstrap-servers incorrecto?)", cause);
        }
        return new KafkaOperationException("No se pudo " + operation + ": " + cause.getMessage(), cause);
    }
}
