package com.pedidos360.kafkaadmin.dto;

import java.util.Map;
import java.util.Set;

/** Configuraciones de topico que esta API permite modificar (lista blanca) y su validacion basica. */
public final class TopicConfigKeys {

    public static final Set<String> ALLOWED = Set.of(
            "retention.ms", "retention.bytes", "cleanup.policy", "min.insync.replicas",
            "max.message.bytes", "segment.ms", "segment.bytes", "compression.type",
            "delete.retention.ms", "min.cleanable.dirty.ratio", "message.timestamp.type");

    private static final Set<String> CLEANUP_VALUES = Set.of("delete", "compact", "compact,delete", "delete,compact");

    private TopicConfigKeys() {
    }

    /** @return mensaje de error o null si todo esta bien */
    public static String validate(Map<String, String> configs) {
        if (configs == null) {
            return null;
        }
        for (Map.Entry<String, String> e : configs.entrySet()) {
            if (e.getKey() == null || !ALLOWED.contains(e.getKey())) {
                return "Configuracion no permitida: '" + e.getKey() + "'. Permitidas: " + ALLOWED;
            }
            if (e.getValue() == null || e.getValue().isBlank()) {
                return "La configuracion '" + e.getKey() + "' no puede tener valor vacio";
            }
            if ("cleanup.policy".equals(e.getKey()) && !CLEANUP_VALUES.contains(e.getValue())) {
                return "cleanup.policy debe ser delete, compact o compact,delete";
            }
        }
        return null;
    }
}
