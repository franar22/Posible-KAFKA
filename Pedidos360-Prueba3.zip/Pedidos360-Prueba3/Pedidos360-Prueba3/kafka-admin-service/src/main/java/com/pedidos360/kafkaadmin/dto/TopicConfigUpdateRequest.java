package com.pedidos360.kafkaadmin.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.AssertTrue;

import java.util.List;
import java.util.Map;

/**
 * Cuerpo de PUT /api/kafka/topics/{name}/config.
 *  set   -> configuraciones a establecer (clave: valor)
 *  reset -> configuraciones que vuelven a su valor por defecto del broker
 */
public record TopicConfigUpdateRequest(Map<String, String> set, List<String> reset) {

    @JsonIgnore
    @AssertTrue(message = "Debes indicar al menos una configuracion en 'set' o en 'reset'")
    public boolean isNotEmpty() {
        return (set != null && !set.isEmpty()) || (reset != null && !reset.isEmpty());
    }

    @JsonIgnore
    @AssertTrue(message = "'set' contiene claves o valores no permitidos")
    public boolean isSetValid() {
        return TopicConfigKeys.validate(set) == null;
    }

    @JsonIgnore
    @AssertTrue(message = "'reset' contiene claves no permitidas")
    public boolean isResetValid() {
        return reset == null || TopicConfigKeys.ALLOWED.containsAll(reset);
    }
}
