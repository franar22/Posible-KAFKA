package com.pedidos360.kafkaadmin.exception;

/** Kafka no responde (brokers caidos o timeout). Se traduce a HTTP 503. */
public class KafkaUnavailableException extends RuntimeException {
    public KafkaUnavailableException(String message, Throwable cause) {
        super(message, cause);
    }
}
