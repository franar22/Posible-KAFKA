package com.pedidos360.kafkaadmin.dto;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.validation.constraints.AssertTrue;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Cuerpo de POST /api/kafka/topics. Valida el nombre y los parametros de administracion
 * (particiones, factor de replicacion, retencion, cleanup policy, min.insync.replicas).
 */
public record TopicCreateRequest(
        @NotBlank(message = "El nombre del topico es obligatorio")
        @Pattern(regexp = "^(?!__)(?!\\.{1,2}$)[A-Za-z0-9._-]{1,249}$",
                message = "Nombre invalido: solo letras, numeros, '.', '_' y '-' (max 249), sin empezar con '__'")
        String name,

        @NotNull(message = "partitions es obligatorio")
        @Min(value = 1, message = "partitions debe ser al menos 1")
        @Max(value = 100, message = "partitions no puede superar 100")
        Integer partitions,

        @NotNull(message = "replicationFactor es obligatorio")
        @Min(value = 1, message = "replicationFactor debe ser al menos 1")
        @Max(value = 7, message = "replicationFactor no puede superar 7")
        Integer replicationFactor,

        /** Retencion en milisegundos (-1 = infinita). */
        @Min(value = -1, message = "retentionMs debe ser -1 (infinita) o mayor")
        Long retentionMs,

        CleanupPolicy cleanupPolicy,

        @Min(value = 1, message = "minInsyncReplicas debe ser al menos 1")
        Integer minInsyncReplicas,

        @Min(value = 1024, message = "maxMessageBytes debe ser al menos 1024")
        Long maxMessageBytes,

        /** Otras configuraciones permitidas (ver TopicConfigKeys.ALLOWED). */
        Map<String, String> configs) {

    @JsonIgnore
    @AssertTrue(message = "minInsyncReplicas no puede ser mayor que replicationFactor")
    public boolean isMinInsyncConsistent() {
        return minInsyncReplicas == null || replicationFactor == null || minInsyncReplicas <= replicationFactor;
    }

    @JsonIgnore
    @AssertTrue(message = "configs contiene claves o valores no permitidos")
    public boolean isConfigsValid() {
        return TopicConfigKeys.validate(configs) == null;
    }

    /** Une los campos tipados y el mapa libre en las configuraciones que se envian a Kafka. */
    public Map<String, String> toConfigMap() {
        Map<String, String> result = new LinkedHashMap<>();
        if (configs != null) {
            result.putAll(configs);
        }
        if (retentionMs != null) {
            result.put("retention.ms", String.valueOf(retentionMs));
        }
        if (cleanupPolicy != null) {
            result.put("cleanup.policy", cleanupPolicy.kafkaValue());
        }
        if (minInsyncReplicas != null) {
            result.put("min.insync.replicas", String.valueOf(minInsyncReplicas));
        }
        if (maxMessageBytes != null) {
            result.put("max.message.bytes", String.valueOf(maxMessageBytes));
        }
        return result;
    }
}
