package com.pedidos360.kafkaadmin.exception;

/** Kafka rechazo la operacion por una razon no prevista. Se traduce a HTTP 502. */
public class KafkaOperationException extends RuntimeException {
    public KafkaOperationException(String message, Throwable cause) {
        super(message, cause);
    }
}
