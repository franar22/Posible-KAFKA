package com.pedidos360.kafkaadmin.controller;

import com.pedidos360.kafkaadmin.dto.ApiResponseDTO;
import com.pedidos360.kafkaadmin.dto.KafkaViews.ClusterView;
import com.pedidos360.kafkaadmin.service.KafkaAdminService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/** GET /api/kafka/cluster : brokers del clúster y cual es el controlador. */
@RestController
@RequestMapping("/api/kafka/cluster")
@PreAuthorize("hasRole('ADMIN')")
public class ClusterController {

    private final KafkaAdminService adminService;

    public ClusterController(KafkaAdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping
    public ResponseEntity<ApiResponseDTO<ClusterView>> cluster() {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Clúster Kafka", adminService.describeCluster(), 1L));
    }
}
