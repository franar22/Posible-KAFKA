package com.pedidos360.kafkaadmin.controller;

import com.pedidos360.kafkaadmin.dto.ApiResponseDTO;
import com.pedidos360.kafkaadmin.dto.KafkaViews.GroupDetail;
import com.pedidos360.kafkaadmin.dto.KafkaViews.GroupLag;
import com.pedidos360.kafkaadmin.dto.KafkaViews.GroupSummary;
import com.pedidos360.kafkaadmin.service.KafkaAdminService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * Recurso "consumer-groups" (supervision de consumidores):
 *   GET    /api/kafka/consumer-groups              lista grupos con su estado
 *   GET    /api/kafka/consumer-groups/{id}         miembros y particiones asignadas a cada uno
 *   GET    /api/kafka/consumer-groups/{id}/lag     offset actual, offset final y LAG por particion
 *   DELETE /api/kafka/consumer-groups/{id}         elimina un grupo sin miembros activos
 */
@RestController
@RequestMapping("/api/kafka/consumer-groups")
@PreAuthorize("hasRole('ADMIN')")
public class ConsumerGroupController {

    private final KafkaAdminService adminService;

    public ConsumerGroupController(KafkaAdminService adminService) {
        this.adminService = adminService;
    }

    @GetMapping
    public ResponseEntity<ApiResponseDTO<List<GroupSummary>>> list() {
        List<GroupSummary> groups = adminService.listConsumerGroups();
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Consumer groups obtenidos satisfactoriamente", groups, (long) groups.size()));
    }

    @GetMapping("/{groupId}")
    public ResponseEntity<ApiResponseDTO<GroupDetail>> get(@PathVariable String groupId) {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Consumer group encontrado", adminService.describeConsumerGroup(groupId), 1L));
    }

    @GetMapping("/{groupId}/lag")
    public ResponseEntity<ApiResponseDTO<GroupLag>> lag(@PathVariable String groupId) {
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Lag del consumer group", adminService.consumerGroupLag(groupId), 1L));
    }

    @DeleteMapping("/{groupId}")
    public ResponseEntity<ApiResponseDTO<Object>> delete(@PathVariable String groupId) {
        adminService.deleteConsumerGroup(groupId);
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Consumer group eliminado satisfactoriamente", null, 1L));
    }
}
