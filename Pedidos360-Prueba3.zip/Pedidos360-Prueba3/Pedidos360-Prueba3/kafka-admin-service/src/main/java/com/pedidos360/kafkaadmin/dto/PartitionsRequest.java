package com.pedidos360.kafkaadmin.dto;

import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotNull;

/** Cuerpo de PATCH /api/kafka/topics/{name}/partitions. Kafka solo permite AUMENTAR particiones. */
public record PartitionsRequest(
        @NotNull(message = "totalPartitions es obligatorio")
        @Min(value = 2, message = "totalPartitions debe ser al menos 2")
        @Max(value = 100, message = "totalPartitions no puede superar 100")
        Integer totalPartitions) {
}
