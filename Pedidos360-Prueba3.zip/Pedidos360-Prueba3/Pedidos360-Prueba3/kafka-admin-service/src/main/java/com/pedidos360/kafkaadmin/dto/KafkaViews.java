package com.pedidos360.kafkaadmin.dto;

import java.util.List;

/** Vistas de solo lectura que devuelve la API (no exponen clases del cliente de Kafka). */
public final class KafkaViews {

    private KafkaViews() {
    }

    public record TopicSummary(String name, int partitions, int replicationFactor) {}

    public record PartitionView(int partition, Integer leader, List<Integer> replicas, List<Integer> isr) {}

    public record ConfigView(String name, String value, String source) {}

    public record TopicDetail(String name, int partitions, int replicationFactor,
                              List<PartitionView> partitionDetails, List<ConfigView> configs) {}

    public record PartitionOffsets(int partition, long earliest, long latest, long messages) {}

    public record TopicOffsets(String topic, long totalMessages, List<PartitionOffsets> partitions) {}

    public record BrokerView(int id, String host, int port, String rack, boolean controller) {}

    public record ClusterView(String clusterId, int brokerCount, List<BrokerView> brokers) {}

    public record MemberView(String consumerId, String clientId, String host, List<String> partitions) {}

    public record GroupSummary(String groupId, String state, int members) {}

    public record GroupDetail(String groupId, String state, String partitionAssignor, String coordinator,
                              List<MemberView> members) {}

    public record LagRow(String topic, int partition, long currentOffset, long logEndOffset, long lag,
                         String consumerId) {}

    public record GroupLag(String groupId, String state, long totalLag, List<LagRow> partitions) {}
}
