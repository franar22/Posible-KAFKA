package com.pedidos360.kafkaadmin.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

import java.util.Set;

/**
 * Configuracion centralizada (application.yml, prefijo pedidos360.kafka).
 * Los nombres de los topicos de negocio se definen UNA sola vez aqui; el servicio los usa para
 * protegerlos de un borrado accidental.
 */
@ConfigurationProperties(prefix = "pedidos360.kafka")
public record KafkaAdminProperties(String bootstrapServers, int requestTimeoutMs, Topics topics) {

    public record Topics(String pedidos, String inventario, String dlt) {}

    /** Topicos que no se pueden eliminar sin ?force=true. */
    public Set<String> protectedTopics() {
        return Set.of(topics.pedidos(), topics.inventario(), topics.dlt());
    }
}
