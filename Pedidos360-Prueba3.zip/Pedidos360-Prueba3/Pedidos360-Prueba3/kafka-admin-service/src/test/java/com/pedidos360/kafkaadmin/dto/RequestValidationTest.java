package com.pedidos360.kafkaadmin.dto;

import jakarta.validation.Validation;
import jakarta.validation.Validator;
import org.junit.jupiter.api.Test;

import java.util.List;
import java.util.Map;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/** Pruebas basicas de validacion de entrada: no se pueden crear topicos con datos invalidos. */
class RequestValidationTest {

    private final Validator validator = Validation.buildDefaultValidatorFactory().getValidator();

    private TopicCreateRequest topic(String name, Integer partitions, Integer rf, Integer minIsr, Map<String, String> configs) {
        return new TopicCreateRequest(name, partitions, rf, 604800000L, CleanupPolicy.DELETE, minIsr, null, configs);
    }

    @Test
    void validTopicHasNoViolations() {
        assertTrue(validator.validate(topic("pedidos360.pedidos.eventos", 3, 3, 2, null)).isEmpty());
    }

    @Test
    void blankNameIsRejected() {
        assertFalse(validator.validate(topic("  ", 3, 3, 2, null)).isEmpty());
    }

    @Test
    void invalidCharactersAndInternalPrefixAreRejected() {
        assertFalse(validator.validate(topic("mi topico!", 3, 3, 2, null)).isEmpty());
        assertFalse(validator.validate(topic("__consumer_offsets", 3, 3, 2, null)).isEmpty());
    }

    @Test
    void partitionsAndReplicationMustBePositive() {
        assertFalse(validator.validate(topic("a", 0, 3, 2, null)).isEmpty());
        assertFalse(validator.validate(topic("a", 3, 0, null, null)).isEmpty());
        assertFalse(validator.validate(topic("a", null, 3, null, null)).isEmpty());
    }

    @Test
    void minInsyncCannotExceedReplicationFactor() {
        assertFalse(validator.validate(topic("a", 3, 2, 3, null)).isEmpty());
    }

    @Test
    void unknownConfigKeysAreRejected() {
        assertFalse(validator.validate(topic("a", 3, 3, 2, Map.of("log.dirs", "/tmp"))).isEmpty());
    }

    @Test
    void typedFieldsAreMergedIntoConfigMap() {
        Map<String, String> map = topic("a", 3, 3, 2, Map.of("segment.ms", "1000")).toConfigMap();
        assertEquals("604800000", map.get("retention.ms"));
        assertEquals("delete", map.get("cleanup.policy"));
        assertEquals("2", map.get("min.insync.replicas"));
        assertEquals("1000", map.get("segment.ms"));
    }

    @Test
    void configUpdateNeedsAtLeastOneChange() {
        assertFalse(validator.validate(new TopicConfigUpdateRequest(null, null)).isEmpty());
        assertTrue(validator.validate(new TopicConfigUpdateRequest(Map.of("retention.ms", "1000"), null)).isEmpty());
        assertFalse(validator.validate(new TopicConfigUpdateRequest(Map.of("cleanup.policy", "otra"), null)).isEmpty());
        assertFalse(validator.validate(new TopicConfigUpdateRequest(null, List.of("log.dirs"))).isEmpty());
    }

    @Test
    void partitionsRequestMustBeAtLeastTwo() {
        assertFalse(validator.validate(new PartitionsRequest(1)).isEmpty());
        assertTrue(validator.validate(new PartitionsRequest(6)).isEmpty());
    }
}
