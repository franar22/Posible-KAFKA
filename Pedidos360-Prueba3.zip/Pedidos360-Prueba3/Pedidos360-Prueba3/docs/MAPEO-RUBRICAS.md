# Mapeo a las rúbricas (Evaluación Parcial 2 y 3 – RabbitMQ) y a la guía del profesor

## Evaluación 3 – Encargo (código)

| Indicador (peso) | Dónde está | Cómo demostrarlo |
|---|---|---|
| Nombres de colas/exchanges/bindings centralizados (12%) | `application.yml` → `pedidos360.rabbit.*` + `config/RabbitNamesProperties.java` (en los 3 servicios, idénticos). Los consumidores usan `${pedidos360.rabbit.queues.*}`. | Buscar nombres de colas (`.q`, `pedidos360.direct`) en `*.java`: solo aparecen prefijos de propiedades, ningún nombre de cola. |
| Beans `Queue`/`Exchange`/`Binding` por caso de uso (13%) | `config/RabbitTopologyConfig.java`: notificaciones (topic), tickets (direct), inventario (topic) + DLX + una DLQ por cola. | Consola RabbitMQ → Exchanges/Queues. |
| Negocio separado de la configuración de mensajería (10%) | `OrderService`/`StockService` solo publican un evento de dominio (`ApplicationEventPublisher`); `messaging/publisher/*` y `config/Rabbit*` aíslan RabbitMQ. | Mostrar que `OrderService` no importa nada de AMQP. |
| Consumidores con `@RabbitListener` por dominio (15%) | `order-service/.../messaging/consumer/notificacion`, `.../ticket`; `catalog-service/.../consumer/inventario`; SQS: `.../consumer/auditoria` (`@SqsListener`). | Paquetes por dominio. |
| ACK y manejo de errores (20%) | `messaging/support/ReliableMessageProcessor.java` + `ack-mode: manual`, `default-requeue-rejected: false`: ACK explícito; no recuperable → NACK sin requeue → DLQ; recuperable → 3 reintentos con backoff → DLQ; todo con log `MENSAJE A DLQ`. Consumidores idempotentes. | `docs/pruebas.http` #14 (JSON corrupto) y #15 (3 reintentos y DLQ); ver logs y la DLQ. |
| API REST del administrador (13%) | `rabbit-admin-service/controller/*`: `POST/GET/DELETE /api/rabbit/queues`, `/exchanges`, `/bindings`, `DELETE /queues/{name}/messages`, `POST /messages`. | Swagger `:8083/doc/swagger-ui.html`. |
| Servicio dedicado `RabbitAdminService` (10%) | `rabbit-admin-service/service/RabbitAdminService.java` (único que toca `RabbitAdmin`). | Controladores sin imports de AMQP. |
| Validación de entrada (7%) | DTOs `QueueRequest`, `ExchangeRequest`, `BindingRequest`, `PublishRequest` con Bean Validation + `GlobalExceptionHandler` (400 con mensajes claros, 404, 409). Test: `RequestValidationTest`. | `pruebas.http` #9 (nombre vacío → 400). |

Además (enunciado Ev.3): filtros JWT de Cognito en cada servicio (`SecurityConfig` + `CognitoGroupsConverter`), integración con RDS (entidades/repositorios/propiedades por variables de entorno), mensajes no entregados a DLQ y registrados en logs, `.gitignore` por tecnología, pruebas básicas (`mvn test`).

## Evaluación 2 – Presentación (checklist de demostración)

| Debes mostrar | Cómo |
|---|---|
| API Manager creado y configurado hacia el backend | API Gateway → `pedidos360-api` → Routes (`/api/catalog|orders|rabbit`) → Integrations (EC2). Script `03-create-api-gateway.sh`. |
| Frontend consume vía API Manager | Amplify con `VITE_API_URL` = URL del API Gateway; DevTools → Network. |
| API Manager valida JWT (rechaza/acepta) | `curl` sin token → 401; con token → 200 (`pruebas.http` #1 y #2). Authorizer `cognito-jwt`. |
| Tenant/IDaaS y usuarios | Cognito User Pool (Prueba 1): usuarios admin/operador/cliente y grupos. |
| Frontend usa OAuth2/OIDC y obtiene JWT | Login de Cognito (react-oidc-context) → token en `sessionStorage`. |
| Backend y frontend desplegados e integrados | EC2 (`docker compose ps`) + Amplify. |
| **Dos nodos RabbitMQ en clúster** | Consola `:15672` → Admin → Nodes (rabbit1 y rabbit2) o `docker exec rabbit1 rabbitmqctl cluster_status`. Config: `infra/rabbitmq/cluster.conf`. |
| **Tres colas con sus DLQ funcionando** | Queues: `notificaciones.q`, `tickets.q`, `inventario.q` y sus `.dlq`; provocar DLQ con `pruebas.http` #14/#15. |
| **Exchanges direct y topic** | Exchanges: `pedidos360.direct` (direct) y `pedidos360.topic` (topic) + Bindings. |
| **docker-compose levantando RabbitMQ en la nube** | `docker compose ps` en la EC2 con `rabbit1`, `rabbit2`. |

## Guía del profesor (SQS/SNS/Lambda/CloudWatch)
Fan-out SNS → 2 colas SQS con DLQ y `maxReceiveCount=3` (`01-create-sns-sqs.sh`), long polling 20 s, visibility timeout 60 s,
consumidor `@SqsListener` idempotente (`event_id` UNIQUE), Lambda con `SQSBatchResponse`, tickets en S3 (claim check),
alarma de DLQ en CloudWatch (`04-create-alarms.sh`), logs con el id del pedido, y patrón Outbox documentado como mejora (dual-write).

## Limitaciones conocidas (para ser honesto en la defensa)
* Publicación post-commit sin *Transactional Outbox*: si el proceso muere entre el commit y el envío, se pierde el evento.
* Reserva de stock síncrona + compensación (mini-saga) en lugar de una saga completa.
* El correo/notificación del laboratorio se simula con logs (SES requiere identidades verificadas).
* Colas clásicas con política HA `ha-mode: all` sobre 2 nodos (en producción: *quorum queues* con 3 nodos).


---

# Prueba 3 – Kafka

## Evaluación 5 – Encargo (código)

| Indicador (peso) | Dónde está | Cómo demostrarlo |
|---|---|---|
| Configuración completa del cliente Kafka (12%) | `application.yml` → `spring.kafka.*` (bootstrap servers de los 3 brokers por variable `KAFKA_BOOTSTRAP_SERVERS`, serializers, deserializers, `acks=all`, idempotencia, `group-id`, `auto-offset-reset`, `enable-auto-commit=false`, `CooperativeStickyAssignor`, timeouts) + `config/KafkaClientConfig.java` + `config/KafkaNamesProperties.java` (nombres de tópicos y grupos, centralizados). | Abrir `application.yml` de `order-service` / `catalog-service`. |
| Productores y consumidores con DTO sobre ambos tópicos (12%) | Pedidos: `KafkaOrderPublisher` (order) → `OrderEventKafkaListener` (catalog). Inventario: `KafkaStockPublisher` (catalog) → `StockAlertKafkaListener` (order). DTO: `OrderEvent`/`OrderEventMessage`, `StockAlertEvent`/`StockAlertMessage`. | Kafka UI → *Messages* de ambos tópicos. |
| Microservicio administrador (6%) | `kafka-admin-service`: crear, listar, describir, modificar configuración, aumentar particiones, eliminar tópicos; grupos de consumidores; clúster. | Swagger `:8084/doc/swagger-ui.html`. |
| Productores correctos con DTO y serializers (14%) | `KafkaClientConfig.kafkaProducerFactory` (clave `StringSerializer`, valor JSON con `DelegatingByTypeSerializer`/`JsonSerializer`, `ObjectMapper` de Spring), `KafkaOrderPublisher`, `KafkaStockPublisher` (clave = id de negocio ⇒ orden por clave; publican **después del commit**). | Mostrar clave y valor JSON en Kafka UI. |
| Consumidores con `@KafkaListener` y lógica separada (14%) | `messaging/kafka/consumer/*Listener` solo leen/validan/delegan a `DemandAnalyticsService` (catalog) y `StockWatchService` (order). | Mostrar que los servicios de negocio no importan Kafka. |
| Manejo de errores (12%) | `KafkaClientConfig.kafkaErrorHandler`: reintentos con backoff exponencial, `DeadLetterPublishingRecoverer` → `pedidos360.dlt`, no recuperables directo al DLT; `ErrorHandlingDeserializer`; `KafkaEventValidator` (Bean Validation); logs con tópico/partición/offset; idempotencia por `eventId`. Tests: `KafkaEventValidationTest`, `DemandAnalyticsServiceTest`. | Publicar un JSON inválido (`pruebas.http` K12) y ver el DLT. |
| Parámetros de administración de tópicos (12%) | `infra/kafka/create-topics.sh`: particiones (3), replicación (3), `retention.ms`, `cleanup.policy` (`delete` / `compact,delete`), `min.insync.replicas`, `segment.ms`, `max.message.bytes`; mismos parámetros en `TopicCreateRequest` del admin. | Kafka UI → tópico → *Settings*. |
| Consumer groups (12%) | `catalog-demand-analytics` (concurrency 3 ⇒ reparte las 3 particiones) y `order-stock-watch`; grupos distintos ⇒ cada servicio recibe todo; rebalanceo cooperativo. | Kafka UI → *Consumers*. |
| Administración con servicio/scripts: crear, actualizar, inspeccionar tópicos y grupos (6%) | `kafka-admin-service` (`/topics`, `/consumer-groups`, `/lag`, `/cluster`) + `create-topics.sh` + `demo-tolerancia-fallos.sh`. | `pruebas.http` K1–K11. |

Del enunciado general: **docker-compose funcional** para Kafka con Zookeeper y brokers (`infra/kafka/docker-compose.kafka.yml`), para **Kafka UI** (`infra/kafka/docker-compose.kafka-ui.yml`) y para el **clúster RabbitMQ** (`infra/rabbitmq/docker-compose.rabbitmq.yml`); el `docker-compose.yml` de la raíz los reúne.

## Evaluación 6 – Presentación (checklist Kafka)

| Indicador (peso) | Qué mostrar / decir | Material |
|---|---|---|
| Arquitectura Kafka con Compose: 3 Zookeeper, 3 brokers, tolerancia a fallos (10%) | Diagrama, roles, quórum 2 de 3, RF 3, `min.insync.replicas=2`; `demo-tolerancia-fallos.sh`. | `docs/KAFKA-ARQUITECTURA.md` §1–2 |
| Justificar 2 tópicos × 3 particiones × 3 réplicas (10%) | Paralelismo (3 consumidores), orden por clave, resiliencia, reparto de líderes. | §3 |
| Kafka UI (5%) | Brokers, tópicos, particiones, mensajes, consumers. | §8 |
| Flujo completo de producción/consumo (12%) | Pedido → tópico → analítica; stock bajo → tópico → order-service. | §5 |
| Diseño de los eventos (6%) | Campos y para qué sirve cada uno. | §4 |
| Respuesta en cuasi tiempo real (12%) | Crear pedido y ver cambiar `top-products` y los logs al instante. | §5 |
| Administración de Kafka: particiones, réplicas, retention, consumer groups (15%) | Settings del tópico, `PUT /topics/{name}/config` para cambiar `retention.ms` en vivo. | §3, §7, §8 |
| Supervisión: offsets, lag, distribución (15%) | Kafka UI *Consumers* + `GET /consumer-groups/{id}/lag`; explicar cómo anticipar problemas. | §8 |
| Casos de uso (15%) | Tabla de casos de uso ↔ configuración. | §9 |

Otros ítems de la Evaluación 6 (API Manager, Cognito, dos nodos RabbitMQ, 3 colas + DLQ, exchanges direct/topic, docker-compose en la nube) siguen cubiertos como en la sección de la Evaluación 2 de este mismo documento.
