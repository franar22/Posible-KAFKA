# Kafka en Pedidos360 – Arquitectura, decisiones y guion de presentación (Evaluaciones 5 y 6)

> Kafka **complementa** a RabbitMQ y SNS/SQS; no los reemplaza ni los modifica. Si `PEDIDOS360_KAFKA_ENABLED=false`
> el sistema funciona exactamente como en la Prueba 2.

## 1. Qué se levanta con Docker Compose

```
                    ┌────────────── Zookeeper (ensemble, quorum = 2 de 3) ──────────────┐
                    │  zookeeper1 (id 1)     zookeeper2 (id 2)     zookeeper3 (id 3)    │
                    └──────────▲──────────────────▲──────────────────▲──────────────────┘
                               │ metadatos, elección de controlador, configuración
                    ┌──────────┴──────┐  ┌────────┴────────┐  ┌──────┴──────────┐
                    │ kafka1 (id 1)   │  │ kafka2 (id 2)   │  │ kafka3 (id 3)   │   3 brokers
                    │ :29092 interno  │  │ :29092 interno  │  │ :29092 interno  │   (replicación x3)
                    │ :9092  externo  │  │ :9093  externo  │  │ :9094  externo  │
                    └──────────▲──────┘  └────────▲────────┘  └──────▲──────────┘
        kafka-init (crea topicos) ┘                │                  └─ kafka-ui :8090 (administración web)
                                  microservicios (producen / consumen) y kafka-admin-service (AdminClient)
```

| Archivo | Qué levanta |
|---|---|
| `infra/kafka/docker-compose.kafka.yml` | 3 Zookeeper + 3 brokers + `kafka-init` (crea los tópicos) |
| `infra/kafka/docker-compose.kafka-ui.yml` | Kafka UI (http://localhost:8090) |
| `infra/rabbitmq/docker-compose.rabbitmq.yml` | Clúster RabbitMQ de 2 nodos (sigue igual que en la Prueba 2) |
| `docker-compose.yml` (raíz) | **Todo junto**: RabbitMQ + Kafka + Kafka UI + los 4 microservicios |

```bash
docker compose up -d --build          # todo el sistema (EC2 t3.large recomendada: ~8 GB de RAM)
docker compose -f infra/kafka/docker-compose.kafka.yml up -d      # solo Kafka (archivo independiente)
docker compose -f infra/kafka/docker-compose.kafka-ui.yml up -d   # solo Kafka UI (sobre ese Kafka)
```

### Rol de cada pieza (lo que debes explicar)
* **Zookeeper (3 nodos)**: es el "cerebro de coordinación" de Kafka (versión con Zookeeper). Guarda los metadatos del
  clúster (qué brokers están vivos, qué tópicos existen, quién es el líder de cada partición), ayuda a **elegir el
  controlador** y almacena configuración. Un *ensemble* de 3 funciona por **quórum (mayoría = 2 de 3)**: elige un
  **leader** y dos **followers**. Si cae 1 nodo, los otros 2 mantienen el quórum y el clúster sigue operando.
  Con 2 nodos caídos se pierde el quórum. (Por eso se usan cantidades impares: 3 tolera 1 caída, 5 toleraría 2.)
* **Brokers (3)**: son los servidores que **almacenan los mensajes** (en particiones) y atienden a productores y
  consumidores. Cada partición tiene 1 **líder** (atiende lecturas/escrituras) y 2 **seguidores** que copian al líder.
  Si un broker cae, el controlador elige un nuevo líder entre las réplicas **en sincronía (ISR)**.
* **kafka-init**: contenedor que corre una vez y crea los tópicos con `infra/kafka/create-topics.sh` (replicable).
* **Kafka UI**: consola web para ver brokers, tópicos, particiones, mensajes, consumer groups y lag, y para crear/borrar tópicos.
* **Doble listener**: `INTERNAL` (`kafka1:29092`, entre contenedores) y `EXTERNAL` (`localhost:9092`, desde fuera de Docker).

## 2. Disponibilidad y tolerancia a fallos: cómo se configuró

| Configuración | Valor | Efecto |
|---|---|---|
| Brokers | 3 | Se tolera la caída de 1 sin perder datos ni servicio |
| `replication-factor` de los tópicos | 3 | Cada partición existe en los 3 brokers |
| `min.insync.replicas` | 2 | Un mensaje "confirmado" está en al menos 2 brokers |
| Productor `acks=all` + `enable.idempotence=true` | – | El líder confirma solo cuando las réplicas en ISR lo tienen; los reintentos no duplican |
| `unclean.leader.election.enable` | false | Nunca se elige líder a una réplica desactualizada (se prioriza no perder datos) |
| `offsets.topic.replication.factor` | 3 | También los offsets de los consumer groups están replicados |
| Zookeeper | 3 nodos | Metadatos con quórum |

Resultado: **se puede caer 1 broker y 1 nodo Zookeeper al mismo tiempo y todo sigue funcionando**. Si caen 2 brokers,
el ISR queda en 1 (< `min.insync.replicas`) y Kafka **rechaza las escrituras** (`NotEnoughReplicas`) antes que arriesgar
datos: elige **consistencia sobre disponibilidad** en ese caso extremo. Los pedidos igual se guardan en MySQL porque
la mensajería nunca rompe la lógica de negocio.

Demostración guiada: `bash infra/kafka/demo-tolerancia-fallos.sh` (apaga y enciende `kafka2` y `zookeeper1` mostrando el ISR).

## 3. Tópicos (exactamente dos de negocio, con 3 particiones y 3 réplicas)

| Tópico | Clave | Productor | Consumidor (group) | Retención | `cleanup.policy` |
|---|---|---|---|---|---|
| `pedidos360.pedidos.eventos` | `orderId` | order-service | catalog-service (`catalog-demand-analytics`) | 7 días | `delete` |
| `pedidos360.inventario.eventos` | `productId` | catalog-service | order-service (`order-stock-watch`) | 30 días | `compact,delete` |
| `pedidos360.dlt` *(operacional)* | clave original | ambos (error handler) | – (se inspecciona en Kafka UI) | 30 días | `delete` |

**Por qué 3 particiones**: la partición es la unidad de **paralelismo**. Con 3 particiones hasta 3 consumidores del mismo
grupo leen a la vez (en catalog-service `concurrency: 3`); con más volumen se agregan instancias hasta 3 por grupo.
La **clave** (`orderId`) manda todos los eventos de un pedido a la misma partición ⇒ se consumen **en orden**
(CREADO → ACEPTADO → DESPACHADO) aunque haya paralelismo entre pedidos distintos.
**Por qué 3 réplicas**: cada partición está copiada en los 3 brokers ⇒ resiliencia (sección 2). También permite repartir
los líderes: cada broker es líder de ~1 partición de cada tópico (balance de carga de lectura/escritura).
**Por qué retenciones distintas**: pedidos = historial reciente para analítica (7 días bastan). Inventario = estado del
stock por producto: `compact` conserva el **último** evento de cada producto indefinidamente y `delete` limpia a los 30
días; así un consumidor nuevo reconstruye el estado actual sin leer todo el historial.
El DLT guarda 30 días los mensajes fallidos para analizarlos/reprocesarlos.

## 4. Diseño de los eventos (JSON, DTO tipados, versionados)

`OrderEvent` (tópico de pedidos): `eventId, type (PedidoCreado | PedidoEstadoCambiado), version, occurredAt, orderId,
customerId, customerEmail, previousStatus, status, total, items[productId, productName, quantity, unitPrice]`.
`StockAlertEvent` (tópico de inventario): `eventId, type (StockBajo), version, occurredAt, productId, productName, stock, threshold`.

Por qué cada campo: `eventId` (idempotencia: no procesar dos veces), `type`+`version` (evolución del contrato),
`occurredAt` (orden temporal/auditoría), `orderId`/`productId` (clave de partición y de negocio), `items[]` (la analítica
de demanda necesita producto y cantidad **sin** llamar de vuelta al otro servicio), `stock`/`threshold` (decidir urgencia).
Se envían datos mínimos, nunca entidades completas. Cada microservicio tiene **su propia copia** del DTO
(`OrderEventMessage`, `StockAlertMessage`) con `ignoreUnknown=true`: acoplamiento solo por el JSON, no por código.

## 5. Flujo completo (para la demo en vivo)

1. El cliente crea un pedido → `order-service` guarda en MySQL y, **después del commit**, publica `PedidoCreado` en
   `pedidos360.pedidos.eventos` (además de RabbitMQ y SNS, que siguen igual).
2. `catalog-service` (grupo `catalog-demand-analytics`, 3 hilos) consume el evento, lo valida y registra la **demanda por
   producto** en `product_demand` (idempotente por `eventId`+`productId`). Resultado visible: `GET /api/catalog/analytics/top-products`.
3. Al aceptar el pedido, `catalog-service` reserva stock; si queda bajo el umbral publica `StockBajo` en
   `pedidos360.inventario.eventos` (clave `productId`).
4. `order-service` (grupo `order-stock-watch`) consume la alerta y calcula cuántos pedidos abiertos incluyen ese producto
   (log `STOCK BAJO (Kafka) ... pedidos abiertos que lo incluyen: N`).
5. Cualquier mensaje inválido o que falle tras 3 reintentos va a `pedidos360.dlt` con log `DLT <- mensaje descartado`.

**Reacción en cuasi tiempo real**: el efecto aparece en segundos y sin que nadie llame a nada: *se crea un pedido → cambia el
ranking de productos demandados → si hay stock bajo, llega una alerta a otro microservicio*.

**Por qué streaming y no solo colas**: Kafka **retiene** los eventos (varios consumer groups leen lo mismo a su ritmo y
pueden releer), mantiene **orden por clave**, escala por **particiones** y soporta altos volúmenes. RabbitMQ sigue siendo
ideal para tareas puntuales (ticket, notificación) donde el mensaje se consume y desaparece.

## 6. Manejo de errores del consumidor
```
evento OK ............................ commit del offset (ack-mode: record)
JSON ilegible (ErrorHandlingDeserializer) ... DLT directo, sin reintentos
payload inválido (Bean Validation) ........... NonRecoverableEventException → DLT directo
fallo recuperable (BD caída...) .............. 3 intentos con backoff exponencial 0,5 s → 1 s → DLT
```
`KafkaClientConfig` (config) → `DefaultErrorHandler` + `DeadLetterPublishingRecoverer`; `KafkaEventValidator` valida; el
`@KafkaListener` solo lee y delega al servicio de negocio (`DemandAnalyticsService`, `StockWatchService`).
Un mensaje defectuoso **nunca bloquea** la partición ni tumba el servicio.

## 7. Consumer groups
* Grupos distintos ⇒ cada uno recibe **todos** los mensajes (publicar/suscribir entre microservicios).
* Mismo grupo ⇒ las particiones se **reparten** entre sus miembros (balanceo). Si un consumidor cae, **rebalanceo**
  automático (`CooperativeStickyAssignor`: mueve solo lo necesario). Prueba: `docker compose up -d --scale catalog-service=2`
  *(quita antes `container_name` y `ports` de catalog-service en el compose si quieres escalarlo)*.
* `enable-auto-commit=false` + `ack-mode=record`: el offset se confirma **después** de procesar ⇒ *at-least-once*;
  por eso los consumidores son **idempotentes**.

## 8. Administración y monitoreo

### kafka-admin-service (puerto 8084, solo rol ADMIN, JWT de Cognito) – `/api/kafka/...`
| Método y ruta | Acción |
|---|---|
| `POST /topics` | Crear (nombre, particiones, replicationFactor, retentionMs, cleanupPolicy, minInsyncReplicas, configs) |
| `GET /topics` · `GET /topics/{name}` | Listar · detalle (líder, réplicas, ISR por partición y configuración) |
| `GET /topics/{name}/offsets` | Offsets earliest/latest y mensajes por partición |
| `PUT /topics/{name}/config` | **Modificar** configuraciones (`set`) o volver al default (`reset`) |
| `PATCH /topics/{name}/partitions` | Aumentar particiones |
| `DELETE /topics/{name}` | Eliminar (`?force=true` para los tópicos de negocio) |
| `GET /consumer-groups` · `/{id}` | Grupos, miembros y particiones asignadas |
| `GET /consumer-groups/{id}/lag` | Offset actual, offset final y **lag** por partición |
| `DELETE /consumer-groups/{id}` | Eliminar un grupo sin miembros |
| `GET /cluster` | Brokers y controlador |

Arquitectura del servicio: `controller` → `KafkaAdminService` (única clase que usa el `AdminClient`) → Kafka. DTOs con
Bean Validation (nombre válido, particiones 1–100, `min.insync.replicas ≤ replicationFactor`, solo claves de configuración
permitidas). Errores traducidos a 400/404/409/502/503.

### Kafka UI (http://IP:8090) – qué mostrar
* **Brokers**: los 3 con su id, controlador y particiones que lideran.
* **Topics**: los dos tópicos con 3 particiones y replication factor 3; pestañas *Messages* (ver JSON), *Consumers*, *Settings* (retention, cleanup.policy, min.insync.replicas).
* **Consumers**: `catalog-demand-analytics` y `order-stock-watch` con estado, miembros y **lag**.

### Métricas para anticipar problemas
**Offset** = posición de un mensaje en la partición. **Log end offset** = último mensaje escrito. **Current offset** = hasta
dónde leyó el grupo. **Lag = end − current**. Lag creciente ⇒ el consumidor no da abasto (agregar instancias, hasta 3 por
grupo) o está caído/atascado; lag concentrado en una partición ⇒ clave "caliente" o consumidor trabado; mensajes
creciendo en el DLT ⇒ productores enviando datos malos o bug de negocio; ISR < 3 ⇒ un broker caído o lento.

## 9. Casos de uso que justifican la configuración
| Caso de uso | Configuración Kafka | Por qué |
|---|---|---|
| Analítica de demanda en cuasi tiempo real | tópico pedidos, 3 particiones, grupo propio con 3 hilos, retención 7 d | Paralelismo y posibilidad de recalcular releyendo |
| Estado de stock / alertas | tópico inventario, `compact,delete`, clave `productId` | Último estado por producto siempre disponible |
| Orden de eventos de un pedido | clave `orderId` | Misma partición ⇒ mismo orden |
| Tolerancia a fallos | RF 3, `min.insync.replicas=2`, `acks=all` | Sin pérdida ante caída de 1 broker |
| Mensajes defectuosos | DLT + reintentos con backoff | El sistema no se detiene |
| Agregar un nuevo consumidor (p. ej. BI) | Nuevo `group.id` | Recibe todo el historial sin tocar a los demás |

## 10. Guion sugerido (5–10 min, Evaluación 6)
1. **(1 min) Arquitectura**: diagrama de la sección 1; roles de Zookeeper (quórum) y brokers (réplicas); qué pasa si cae uno.
2. **(1 min) Compose en la nube**: en la EC2, `docker compose ps` (todo *healthy*) y `docker compose logs kafka-init`.
3. **(2 min) Kafka UI**: brokers → tópicos (3 particiones, RF 3, retención, cleanup) → justificar los números.
4. **(2 min) Flujo en vivo**: crear un pedido desde el frontend → *Messages* del tópico → logs de `catalog-service`
   (`ANALITICA`) → `GET /api/catalog/analytics/top-products` → aceptar pedido hasta provocar stock bajo → log en `order-service`.
5. **(1 min) Monitoreo**: pestaña *Consumers* y `GET /api/kafka/consumer-groups/{id}/lag`; explicar offsets y lag.
6. **(1 min) Tolerancia**: `docker stop kafka2` → ISR baja a 2 y el pedido igual se procesa → `docker start kafka2`.
7. **(1 min) Administración**: Swagger de kafka-admin-service (`POST /topics`, `PUT /config`) y por qué es una capa de gestión replicable.

Para la parte de Evaluación 6 que pide RabbitMQ (2 nodos, 3 colas + DLQ, exchanges direct/topic) ver `docs/MAPEO-RUBRICAS.md`.
