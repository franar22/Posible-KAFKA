#!/usr/bin/env bash
# =====================================================================
# Crea (de forma idempotente) los topicos de Kafka de Pedidos360.
# Lo ejecuta el contenedor "kafka-init" de docker-compose, pero tambien se puede correr a mano:
#   BOOTSTRAP=localhost:9092 bash infra/kafka/create-topics.sh      (requiere kafka-topics en el PATH)
#
# Requisito de la rubrica: DOS topicos de negocio con 3 particiones y 3 replicas cada uno.
#   1) pedidos360.pedidos.eventos     eventos de pedidos      (retencion 7 dias, cleanup.policy=delete)
#   2) pedidos360.inventario.eventos  eventos de inventario   (retencion 30 dias, cleanup.policy=compact,delete)
# Adicional (operacional, no es de negocio):
#   3) pedidos360.dlt                 Dead Letter Topic: mensajes que fallaron tras los reintentos
#
# min.insync.replicas=2 + acks=all (productores)  =>  un mensaje confirmado vive en >= 2 brokers:
# se puede caer 1 broker sin perder datos y sin dejar de aceptar escrituras.
# =====================================================================
set -euo pipefail

BOOTSTRAP="${BOOTSTRAP:-kafka1:29092,kafka2:29092,kafka3:29092}"
PARTITIONS="${TOPIC_PARTITIONS:-3}"
REPLICATION="${TOPIC_REPLICATION_FACTOR:-3}"
MIN_ISR="${TOPIC_MIN_ISR:-2}"

TOPIC_PEDIDOS="${TOPIC_PEDIDOS:-pedidos360.pedidos.eventos}"
TOPIC_INVENTARIO="${TOPIC_INVENTARIO:-pedidos360.inventario.eventos}"
TOPIC_DLT="${TOPIC_DLT:-pedidos360.dlt}"

DAY_MS=86400000

create_topic() {   # $1 = nombre  $2.. = --config k=v ...
  local name="$1"; shift
  echo ">> Creando topico ${name} (particiones=${PARTITIONS}, replicas=${REPLICATION})"
  kafka-topics --bootstrap-server "$BOOTSTRAP" --create --if-not-exists \
    --topic "$name" --partitions "$PARTITIONS" --replication-factor "$REPLICATION" "$@"
}

# 1) Eventos de pedidos: se leen como "historial" reciente -> se borran por tiempo (7 dias)
create_topic "$TOPIC_PEDIDOS" \
  --config cleanup.policy=delete \
  --config retention.ms=$((7 * DAY_MS)) \
  --config min.insync.replicas="$MIN_ISR" \
  --config max.message.bytes=1048576 \
  --config segment.ms=$((1 * DAY_MS))

# 2) Eventos de inventario: clave = productId. "compact" conserva el ULTIMO evento de cada producto
#    (estado mas reciente del stock) y "delete" limpia lo antiguo a los 30 dias.
create_topic "$TOPIC_INVENTARIO" \
  --config cleanup.policy=compact,delete \
  --config retention.ms=$((30 * DAY_MS)) \
  --config min.cleanable.dirty.ratio=0.1 \
  --config min.insync.replicas="$MIN_ISR" \
  --config max.message.bytes=1048576 \
  --config segment.ms=$((1 * DAY_MS))

# 3) Dead Letter Topic: se conserva 30 dias para poder analizar y reprocesar los mensajes defectuosos
create_topic "$TOPIC_DLT" \
  --config cleanup.policy=delete \
  --config retention.ms=$((30 * DAY_MS)) \
  --config min.insync.replicas="$MIN_ISR"

echo
echo ">> Estado final de los topicos:"
kafka-topics --bootstrap-server "$BOOTSTRAP" --describe --topic "$TOPIC_PEDIDOS"
kafka-topics --bootstrap-server "$BOOTSTRAP" --describe --topic "$TOPIC_INVENTARIO"
kafka-topics --bootstrap-server "$BOOTSTRAP" --describe --topic "$TOPIC_DLT"
echo ">> Listo."
