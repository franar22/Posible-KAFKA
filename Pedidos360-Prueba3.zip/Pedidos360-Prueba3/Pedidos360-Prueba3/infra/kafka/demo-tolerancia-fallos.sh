#!/usr/bin/env bash
# =====================================================================
# DEMO de disponibilidad y tolerancia a fallos de Kafka (para la presentacion).
# Corre en la maquina donde esta docker compose (EC2 o tu PC). Va por pasos: ENTER para continuar.
#   bash infra/kafka/demo-tolerancia-fallos.sh
# =====================================================================
set -uo pipefail

BOOT="kafka1:29092,kafka2:29092,kafka3:29092"
T1="${TOPIC_PEDIDOS:-pedidos360.pedidos.eventos}"

pause() { echo; read -r -p ">> ENTER para continuar..." _; echo; }
title() { echo; echo "=================== $* ==================="; }
describe() { docker exec kafka1 kafka-topics --bootstrap-server "$BOOT" --describe --topic "$T1"; }
zk_mode() {
  for n in zookeeper1 zookeeper2 zookeeper3; do
    printf "%-11s " "$n"
    docker exec "$n" bash -c 'exec 3<>/dev/tcp/localhost/2181; echo srvr >&3; grep Mode <&3' 2>/dev/null || echo "(caido)"
  done
}

title "1) Ensemble de Zookeeper: 1 LEADER + 2 FOLLOWERS (quorum = 2 de 3)"
zk_mode
pause

title "2) Estado normal del topico: 3 particiones, 3 replicas, ISR = [1,2,3]"
describe
pause

title "3) Cae el broker 2 (docker stop kafka2): se eligen nuevos lideres y el ISR baja a 2 replicas"
docker stop kafka2 >/dev/null; sleep 12
describe
echo "-> Con min.insync.replicas=2 y acks=all se SIGUE publicando y consumiendo. Crea un pedido ahora."
pause

title "4) Vuelve el broker 2 (docker start kafka2): se re-sincroniza y vuelve al ISR"
docker start kafka2 >/dev/null; sleep 20
describe
pause

title "5) Cae un nodo Zookeeper (docker stop zookeeper1): el quorum (2 de 3) se mantiene, Kafka sigue operando"
docker stop zookeeper1 >/dev/null; sleep 8
zk_mode
echo "-> Kafka sigue funcionando: crea otro pedido. Con 2 nodos ZK caidos se perderia el quorum."
pause

title "6) Recuperacion: docker start zookeeper1"
docker start zookeeper1 >/dev/null; sleep 12
zk_mode
echo
echo "Demo terminada. (Extra: si paras 2 brokers, el ISR queda en 1 < min.insync.replicas=2 => los productores"
echo " reciben NotEnoughReplicas: Kafka prefiere RECHAZAR escrituras antes que perder datos -> consistencia.)"
