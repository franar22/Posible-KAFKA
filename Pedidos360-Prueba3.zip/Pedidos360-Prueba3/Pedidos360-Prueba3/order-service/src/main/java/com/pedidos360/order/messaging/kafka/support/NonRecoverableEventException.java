package com.pedidos360.order.messaging.kafka.support;

/**
 * Evento invalido o corrupto: reintentar no sirve (siempre fallara). El manejador de errores lo envia
 * directo al Dead Letter Topic, sin reintentos, para que no bloquee la particion.
 */
public class NonRecoverableEventException extends RuntimeException {

    public NonRecoverableEventException(String message) {
        super(message);
    }

    public NonRecoverableEventException(String message, Throwable cause) {
        super(message, cause);
    }
}
