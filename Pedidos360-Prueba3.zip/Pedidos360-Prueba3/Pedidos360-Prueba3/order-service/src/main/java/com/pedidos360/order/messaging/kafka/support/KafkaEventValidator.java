package com.pedidos360.order.messaging.kafka.support;

import jakarta.validation.ConstraintViolation;
import jakarta.validation.Validator;
import org.springframework.stereotype.Component;

import java.util.Set;
import java.util.TreeSet;

/** Valida el contenido (Bean Validation) de un evento recibido. Un evento invalido va directo al DLT. */
@Component
public class KafkaEventValidator {

    private final Validator validator;

    public KafkaEventValidator(Validator validator) {
        this.validator = validator;
    }

    public <T> T requireValid(T event) {
        if (event == null) {
            throw new NonRecoverableEventException("Evento nulo");
        }
        Set<ConstraintViolation<T>> violations = validator.validate(event);
        if (!violations.isEmpty()) {
            Set<String> problems = new TreeSet<>();
            violations.forEach(v -> problems.add(v.getPropertyPath() + " " + v.getMessage()));
            throw new NonRecoverableEventException("Evento invalido: " + problems);
        }
        return event;
    }
}
