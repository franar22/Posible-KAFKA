package com.pedidos360.order.messaging.kafka.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.PositiveOrZero;

import java.time.Instant;

/**
 * DTO tipado del evento "StockBajo" que PRODUCE catalog-service en el topico de inventario y CONSUME order-service.
 * Cada servicio tiene su propia copia del contrato (no comparten codigo): solo importa el JSON.
 * ignoreUnknown = true -> si catalog agrega campos nuevos, este consumidor no se rompe.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record StockAlertMessage(
        @NotBlank String eventId,
        String type,
        int version,
        Instant occurredAt,
        @NotNull Long productId,
        @NotBlank String productName,
        @PositiveOrZero int stock,
        @PositiveOrZero int threshold) {
}
