package com.pedidos360.order.repository;

import com.pedidos360.order.model.Order;
import com.pedidos360.order.model.OrderStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.Collection;
import java.util.List;

public interface OrderRepository extends JpaRepository<Order, Long> {
    List<Order> findByCustomerId(String customerId);

    /** Cantidad de pedidos (distintos) en alguno de esos estados que incluyen el producto. */
    @Query("select count(distinct i.order.id) from OrderItem i "
            + "where i.productId = :productId and i.order.status in :statuses")
    long countOpenOrdersWithProduct(@Param("productId") Long productId,
                                    @Param("statuses") Collection<OrderStatus> statuses);
}
