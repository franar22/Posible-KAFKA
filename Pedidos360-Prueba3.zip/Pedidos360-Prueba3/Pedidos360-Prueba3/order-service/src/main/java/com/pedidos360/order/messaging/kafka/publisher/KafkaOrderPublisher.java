package com.pedidos360.order.messaging.kafka.publisher;

import com.pedidos360.order.config.KafkaNamesProperties;
import com.pedidos360.order.event.OrderEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;

/**
 * PRODUCTOR Kafka de pedidos: publica cada OrderEvent (PedidoCreado / PedidoEstadoCambiado) en el topico
 * de pedidos.  key = id del pedido  =>  todos los eventos de un mismo pedido caen en la MISMA particion
 * y por lo tanto se consumen EN ORDEN (CREADO -> ACEPTADO -> DESPACHADO...).
 * El valor viaja como JSON (el OrderEvent es el DTO). Lo invoca OrderEventDispatcher despues del commit.
 * Si Kafka falla el pedido igual queda guardado (la mensajeria nunca rompe la logica de negocio).
 */
@Component
@ConditionalOnProperty(prefix = "pedidos360.kafka", name = "enabled", havingValue = "true", matchIfMissing = true)
public class KafkaOrderPublisher {

    private static final Logger log = LoggerFactory.getLogger(KafkaOrderPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final KafkaNamesProperties names;

    public KafkaOrderPublisher(KafkaTemplate<String, Object> kafkaTemplate, KafkaNamesProperties names) {
        this.kafkaTemplate = kafkaTemplate;
        this.names = names;
    }

    public void publish(OrderEvent event) {
        String topic = names.topics().pedidos();
        String key = String.valueOf(event.orderId());
        try {
            kafkaTemplate.send(topic, key, event).whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Kafka: no se pudo publicar topic={} key={} type={}", topic, key, event.type(), ex);
                } else {
                    log.info("Kafka publicado topic={} partition={} offset={} key={} type={} estado={}",
                            topic, result.getRecordMetadata().partition(), result.getRecordMetadata().offset(),
                            key, event.type(), event.status());
                }
            });
        } catch (Exception ex) {
            log.error("Kafka: error al enviar topic={} key={} (el pedido igual quedo guardado)", topic, key, ex);
        }
    }
}
