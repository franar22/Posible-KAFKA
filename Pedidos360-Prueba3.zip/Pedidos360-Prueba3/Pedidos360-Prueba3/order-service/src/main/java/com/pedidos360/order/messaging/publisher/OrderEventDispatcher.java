package com.pedidos360.order.messaging.publisher;

import com.pedidos360.order.event.OrderEvent;
import com.pedidos360.order.messaging.kafka.publisher.KafkaOrderPublisher;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

/**
 * Recibe los OrderEvent que publica OrderService y los reparte a los brokers (RabbitMQ, SNS y Kafka) DESPUES del commit.
 * Asi nunca sale un evento de un pedido que finalmente no se guardo, y la logica de negocio queda
 * desacoplada de la mensajeria (OrderService no conoce RabbitMQ ni SNS).
 *
 * Limitacion conocida (dual write): si el proceso muere justo entre el commit y el envio, el evento se pierde.
 * La solucion de produccion es el patron Transactional Outbox (ver docs/ARQUITECTURA.md).
 */
@Component
@ConditionalOnProperty(prefix = "pedidos360.messaging", name = "enabled", havingValue = "true", matchIfMissing = true)
public class OrderEventDispatcher {

    private final RabbitOrderPublisher rabbitPublisher;
    private final SnsOrderPublisher snsPublisher;
    private final ObjectProvider<KafkaOrderPublisher> kafkaPublisher;

    public OrderEventDispatcher(RabbitOrderPublisher rabbitPublisher,
                                SnsOrderPublisher snsPublisher,
                                ObjectProvider<KafkaOrderPublisher> kafkaPublisher) {
        this.rabbitPublisher = rabbitPublisher;
        this.snsPublisher = snsPublisher;
        this.kafkaPublisher = kafkaPublisher;   // ausente si PEDIDOS360_KAFKA_ENABLED=false
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onOrderEvent(OrderEvent event) {
        rabbitPublisher.publish(event);
        snsPublisher.publish(event);
        kafkaPublisher.ifAvailable(publisher -> publisher.publish(event));   // streaming (Kafka): se suma, no reemplaza
    }
}
