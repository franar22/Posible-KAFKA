package com.pedidos360.order.config;

import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Nombres de topicos, grupos de consumidores y politica de reintentos de Kafka.
 * UNICO lugar donde se definen (application.yml, prefijo pedidos360.kafka): ninguna clase de negocio
 * escribe nombres de topicos "a mano".
 */
@ConfigurationProperties(prefix = "pedidos360.kafka")
public record KafkaNamesProperties(Topics topics, Retry retry, Groups groups) {

    /** pedidos: eventos de pedidos | inventario: eventos de stock | dlt: mensajes que fallaron (Dead Letter Topic) */
    public record Topics(String pedidos, String inventario, String dlt) {}

    /** Reintentos antes de mandar el mensaje al DLT (backoff exponencial). */
    public record Retry(int maxAttempts, long initialBackoffMs, double multiplier, long maxBackoffMs) {}

    /** Consumer groups de este microservicio. */
    public record Groups(String stockWatch) {}
}
