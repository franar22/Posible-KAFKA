package com.pedidos360.order.service;

import com.pedidos360.order.messaging.kafka.dto.StockAlertMessage;
import com.pedidos360.order.model.OrderStatus;
import com.pedidos360.order.repository.OrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Logica de negocio (sin nada de Kafka en las firmas de infraestructura): cuando un producto queda con stock
 * bajo, cuenta cuantos pedidos todavia abiertos incluyen ese producto, porque son los que se pueden ver
 * afectados (demora o quiebre de stock) y avisa a operaciones por log.
 */
@Service
public class StockWatchService {

    private static final Logger log = LoggerFactory.getLogger(StockWatchService.class);

    /** Pedidos que aun no salieron de la bodega. */
    static final List<OrderStatus> OPEN_STATUSES =
            List.of(OrderStatus.CREADO, OrderStatus.ACEPTADO, OrderStatus.EN_PREPARACION);

    private final OrderRepository orderRepository;

    public StockWatchService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    @Transactional(readOnly = true)
    public long handle(StockAlertMessage alert) {
        long affected = orderRepository.countOpenOrdersWithProduct(alert.productId(), OPEN_STATUSES);
        log.warn("STOCK BAJO (Kafka) producto={} ({}) stock={} umbral={} -> pedidos abiertos que lo incluyen: {}",
                alert.productName(), alert.productId(), alert.stock(), alert.threshold(), affected);
        return affected;
    }
}
