package com.pedidos360.order.messaging.kafka.consumer;

import com.pedidos360.order.messaging.kafka.dto.StockAlertMessage;
import com.pedidos360.order.messaging.kafka.support.KafkaEventValidator;
import com.pedidos360.order.service.StockWatchService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * CONSUMIDOR Kafka del dominio "inventario" en order-service.
 * Solo se encarga de la MENSAJERIA (leer, loguear, validar); la logica de negocio esta en StockWatchService.
 *  - topico y group-id vienen del application.yml (no estan escritos aqui)
 *  - group-id "order-stock-watch": distinto del grupo de catalog-service => cada servicio recibe TODOS los eventos
 *  - los errores no se capturan aqui: los maneja el DefaultErrorHandler (reintentos -> Dead Letter Topic)
 */
@Component
@ConditionalOnProperty(prefix = "pedidos360", name = {"kafka.enabled", "messaging.consumers-enabled"},
        havingValue = "true", matchIfMissing = true)
public class StockAlertKafkaListener {

    private static final Logger log = LoggerFactory.getLogger(StockAlertKafkaListener.class);

    private final KafkaEventValidator validator;
    private final StockWatchService stockWatchService;

    public StockAlertKafkaListener(KafkaEventValidator validator, StockWatchService stockWatchService) {
        this.validator = validator;
        this.stockWatchService = stockWatchService;
    }

    @KafkaListener(id = "${pedidos360.kafka.groups.stock-watch}",
            topics = "${pedidos360.kafka.topics.inventario}",
            groupId = "${pedidos360.kafka.groups.stock-watch}")
    public void onStockAlert(ConsumerRecord<String, StockAlertMessage> record) {
        log.info("Kafka recibido topic={} partition={} offset={} key={}",
                record.topic(), record.partition(), record.offset(), record.key());

        if (record.value() == null) {   // tombstone de la compactacion: nada que procesar
            log.debug("Kafka: mensaje sin valor (tombstone) key={}, se ignora", record.key());
            return;
        }
        stockWatchService.handle(validator.requireValid(record.value()));
    }
}
