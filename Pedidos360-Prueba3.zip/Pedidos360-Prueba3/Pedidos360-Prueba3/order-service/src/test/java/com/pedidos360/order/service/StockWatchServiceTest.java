package com.pedidos360.order.service;

import com.pedidos360.order.messaging.kafka.dto.StockAlertMessage;
import com.pedidos360.order.repository.OrderRepository;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class StockWatchServiceTest {

    @Test
    void countsOpenOrdersThatIncludeTheProduct() {
        OrderRepository repository = mock(OrderRepository.class);
        when(repository.countOpenOrdersWithProduct(7L, StockWatchService.OPEN_STATUSES)).thenReturn(3L);
        StockWatchService service = new StockWatchService(repository);

        long affected = service.handle(new StockAlertMessage("e1", "StockBajo", 1, Instant.now(), 7L, "Teclado", 2, 5));

        assertEquals(3L, affected);
        verify(repository).countOpenOrdersWithProduct(7L, StockWatchService.OPEN_STATUSES);
    }
}
