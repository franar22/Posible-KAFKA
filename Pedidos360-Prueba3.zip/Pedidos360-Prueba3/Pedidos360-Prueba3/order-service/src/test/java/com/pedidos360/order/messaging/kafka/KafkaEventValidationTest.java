package com.pedidos360.order.messaging.kafka;

import com.pedidos360.order.messaging.kafka.dto.StockAlertMessage;
import com.pedidos360.order.messaging.kafka.support.KafkaEventValidator;
import com.pedidos360.order.messaging.kafka.support.NonRecoverableEventException;
import jakarta.validation.Validation;
import org.junit.jupiter.api.Test;

import java.time.Instant;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

/** Un evento invalido debe rechazarse como "no recuperable" (va directo al Dead Letter Topic). */
class KafkaEventValidationTest {

    private final KafkaEventValidator validator =
            new KafkaEventValidator(Validation.buildDefaultValidatorFactory().getValidator());

    @Test
    void validEventPasses() {
        var event = new StockAlertMessage("e1", "StockBajo", 1, Instant.now(), 1L, "Teclado", 2, 5);
        assertSame(event, validator.requireValid(event));
    }

    @Test
    void missingFieldsAndNegativeStockAreRejected() {
        assertThrows(NonRecoverableEventException.class,
                () -> validator.requireValid(new StockAlertMessage(null, "StockBajo", 1, Instant.now(), null, " ", -1, 5)));
    }

    @Test
    void nullEventIsRejected() {
        assertThrows(NonRecoverableEventException.class, () -> validator.requireValid(null));
    }
}
