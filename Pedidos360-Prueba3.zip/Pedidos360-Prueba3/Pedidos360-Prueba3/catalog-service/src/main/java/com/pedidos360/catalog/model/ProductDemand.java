package com.pedidos360.catalog.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

/**
 * Una unidad de demanda registrada a partir de un evento de pedido de Kafka (analitica en cuasi tiempo real).
 * (event_id, product_id) es UNIQUE: si Kafka entrega el mismo evento dos veces (at-least-once) no se cuenta doble.
 */
@Entity
@Table(name = "product_demand",
        uniqueConstraints = @UniqueConstraint(name = "uk_demand_event_product", columnNames = {"event_id", "product_id"}))
@Getter
@Setter
@NoArgsConstructor
public class ProductDemand {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "event_id", nullable = false, length = 64)
    private String eventId;

    @Column(name = "product_id", nullable = false)
    private Long productId;

    @Column(name = "product_name", length = 120)
    private String productName;

    @Column(nullable = false)
    private Integer quantity;

    @Column(name = "order_id", nullable = false)
    private Long orderId;

    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt = LocalDateTime.now();
}
