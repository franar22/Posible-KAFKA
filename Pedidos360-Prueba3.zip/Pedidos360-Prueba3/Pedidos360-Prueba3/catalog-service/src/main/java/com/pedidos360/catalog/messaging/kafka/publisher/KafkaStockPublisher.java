package com.pedidos360.catalog.messaging.kafka.publisher;

import com.pedidos360.catalog.config.KafkaNamesProperties;
import com.pedidos360.catalog.messaging.StockAlertEvent;
import com.pedidos360.catalog.service.LowStockDetected;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Component;
import org.springframework.transaction.event.TransactionPhase;
import org.springframework.transaction.event.TransactionalEventListener;

import java.time.Instant;
import java.util.UUID;

/**
 * PRODUCTOR Kafka del catalogo: cuando una reserva deja un producto con stock bajo, publica StockAlertEvent en
 * el topico de inventario.  key = productId  =>  todos los eventos de un producto van a la misma particion
 * (orden garantizado) y, como el topico usa cleanup.policy=compact, Kafka conserva el ULTIMO evento por producto.
 * Se ejecuta DESPUES del commit (igual que el productor RabbitMQ): si Kafka cae la reserva igual se confirma.
 */
@Component
@ConditionalOnProperty(prefix = "pedidos360", name = {"kafka.enabled", "messaging.enabled"},
        havingValue = "true", matchIfMissing = true)
public class KafkaStockPublisher {

    private static final Logger log = LoggerFactory.getLogger(KafkaStockPublisher.class);

    private final KafkaTemplate<String, Object> kafkaTemplate;
    private final KafkaNamesProperties names;

    public KafkaStockPublisher(KafkaTemplate<String, Object> kafkaTemplate, KafkaNamesProperties names) {
        this.kafkaTemplate = kafkaTemplate;
        this.names = names;
    }

    @TransactionalEventListener(phase = TransactionPhase.AFTER_COMMIT, fallbackExecution = true)
    public void onLowStock(LowStockDetected detected) {
        String topic = names.topics().inventario();
        String key = String.valueOf(detected.productId());
        try {
            StockAlertEvent event = new StockAlertEvent(
                    UUID.randomUUID().toString(), StockAlertEvent.TYPE, 1, Instant.now(),
                    detected.productId(), detected.productName(), detected.stock(), detected.threshold());

            kafkaTemplate.send(topic, key, event).whenComplete((result, ex) -> {
                if (ex != null) {
                    log.error("Kafka: no se pudo publicar StockBajo topic={} productId={}", topic, key, ex);
                } else {
                    log.info("Kafka publicado StockBajo topic={} partition={} offset={} productId={} stock={}",
                            topic, result.getRecordMetadata().partition(), result.getRecordMetadata().offset(),
                            key, detected.stock());
                }
            });
        } catch (Exception ex) {
            log.error("Kafka: error al enviar StockBajo topic={} productId={} (la reserva igual quedo confirmada)",
                    topic, key, ex);
        }
    }
}
