package com.pedidos360.catalog.controller;

import com.pedidos360.catalog.dto.ApiResponseDTO;
import com.pedidos360.catalog.repository.ProductDemandRepository.DemandSummary;
import com.pedidos360.catalog.service.DemandAnalyticsService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Resultado del streaming: productos mas demandados, calculados a partir de los eventos de pedidos de Kafka. */
@RestController
@RequestMapping("/api/catalog/analytics")
public class DemandAnalyticsController {

    private final DemandAnalyticsService analyticsService;

    public DemandAnalyticsController(DemandAnalyticsService analyticsService) {
        this.analyticsService = analyticsService;
    }

    @GetMapping("/top-products")
    @PreAuthorize("hasAnyRole('ADMIN', 'OPERADOR')")
    public ResponseEntity<ApiResponseDTO<List<Map<String, Object>>>> topProducts(
            @RequestParam(defaultValue = "5") int limit) {
        List<Map<String, Object>> rows = analyticsService.topProducts(limit).stream()
                .map(this::toMap)
                .toList();
        return ResponseEntity.ok(new ApiResponseDTO<>(
                true, HttpStatus.OK.value(), "Productos mas demandados (eventos Kafka)", rows, (long) rows.size()));
    }

    private Map<String, Object> toMap(DemandSummary s) {
        return Map.of("productId", s.getProductId(),
                "productName", s.getProductName() == null ? "" : s.getProductName(),
                "units", s.getUnits(),
                "orders", s.getOrdersCount());
    }
}
