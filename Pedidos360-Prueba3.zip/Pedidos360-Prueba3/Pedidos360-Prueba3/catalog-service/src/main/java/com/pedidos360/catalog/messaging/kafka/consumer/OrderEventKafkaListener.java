package com.pedidos360.catalog.messaging.kafka.consumer;

import com.pedidos360.catalog.messaging.kafka.dto.OrderEventMessage;
import com.pedidos360.catalog.messaging.kafka.support.KafkaEventValidator;
import com.pedidos360.catalog.service.DemandAnalyticsService;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

/**
 * CONSUMIDOR Kafka del dominio "analitica de demanda" en catalog-service.
 * Solo se encarga de la MENSAJERIA (leer, loguear, validar); la logica esta en DemandAnalyticsService.
 *  - group-id "catalog-demand-analytics" con concurrency=3: el topico tiene 3 particiones, asi que 3 hilos
 *    consumidores se reparten las particiones (balanceo de carga). Si se levantan mas instancias de catalog-service,
 *    Kafka reparte las particiones entre ellas (rebalanceo) y si una cae, las demas toman su trabajo.
 *  - otro microservicio con OTRO group-id recibiria igualmente TODOS los eventos (publicar/suscribir).
 */
@Component
@ConditionalOnProperty(prefix = "pedidos360", name = {"kafka.enabled", "messaging.consumers-enabled"},
        havingValue = "true", matchIfMissing = true)
public class OrderEventKafkaListener {

    private static final Logger log = LoggerFactory.getLogger(OrderEventKafkaListener.class);

    private final KafkaEventValidator validator;
    private final DemandAnalyticsService analyticsService;

    public OrderEventKafkaListener(KafkaEventValidator validator, DemandAnalyticsService analyticsService) {
        this.validator = validator;
        this.analyticsService = analyticsService;
    }

    @KafkaListener(id = "${pedidos360.kafka.groups.demand-analytics}",
            topics = "${pedidos360.kafka.topics.pedidos}",
            groupId = "${pedidos360.kafka.groups.demand-analytics}",
            concurrency = "${pedidos360.kafka.consumer.concurrency:3}")
    public void onOrderEvent(ConsumerRecord<String, OrderEventMessage> record) {
        log.info("Kafka recibido topic={} partition={} offset={} key={}",
                record.topic(), record.partition(), record.offset(), record.key());

        if (record.value() == null) {
            log.debug("Kafka: mensaje sin valor (tombstone) key={}, se ignora", record.key());
            return;
        }
        analyticsService.record(validator.requireValid(record.value()));
    }
}
