package com.pedidos360.catalog.repository;

import com.pedidos360.catalog.model.ProductDemand;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface ProductDemandRepository extends JpaRepository<ProductDemand, Long> {

    boolean existsByEventIdAndProductId(String eventId, Long productId);

    /** Productos mas pedidos (unidades y cantidad de pedidos), de mayor a menor demanda. */
    @Query("select d.productId as productId, max(d.productName) as productName, "
            + "sum(d.quantity) as units, count(d) as ordersCount "
            + "from ProductDemand d group by d.productId order by sum(d.quantity) desc")
    List<DemandSummary> topProducts(Pageable pageable);

    interface DemandSummary {
        Long getProductId();

        String getProductName();

        Long getUnits();

        Long getOrdersCount();
    }
}
