package com.pedidos360.catalog.service;

import com.pedidos360.catalog.messaging.kafka.dto.OrderEventMessage;
import com.pedidos360.catalog.model.ProductDemand;
import com.pedidos360.catalog.repository.ProductDemandRepository;
import com.pedidos360.catalog.repository.ProductDemandRepository.DemandSummary;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.domain.PageRequest;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

/**
 * Logica de negocio de la analitica de demanda (sin APIs de Kafka): convierte cada evento "PedidoCreado" en
 * demanda por producto. Es idempotente: reprocesar el mismo evento no duplica los conteos.
 * Los eventos de otros tipos (cambios de estado) se ignoran: no aportan a la demanda.
 */
@Service
public class DemandAnalyticsService {

    private static final Logger log = LoggerFactory.getLogger(DemandAnalyticsService.class);

    private final ProductDemandRepository repository;

    public DemandAnalyticsService(ProductDemandRepository repository) {
        this.repository = repository;
    }

    /** @return cantidad de lineas de demanda nuevas registradas */
    @Transactional
    public int record(OrderEventMessage event) {
        if (!OrderEventMessage.TYPE_CREATED.equals(event.type())) {
            log.debug("Evento {} del pedido {} no afecta la demanda, se ignora", event.type(), event.orderId());
            return 0;
        }
        if (event.items() == null || event.items().isEmpty()) {
            log.warn("PedidoCreado sin items eventId={} pedido={}", event.eventId(), event.orderId());
            return 0;
        }
        int saved = 0;
        for (OrderEventMessage.Item item : event.items()) {
            if (repository.existsByEventIdAndProductId(event.eventId(), item.productId())) {
                log.info("Evento {} producto {} ya procesado, se ignora el duplicado", event.eventId(), item.productId());
                continue;
            }
            ProductDemand demand = new ProductDemand();
            demand.setEventId(event.eventId());
            demand.setProductId(item.productId());
            demand.setProductName(item.productName());
            demand.setQuantity(item.quantity());
            demand.setOrderId(event.orderId());
            repository.save(demand);
            saved++;
        }
        log.info("ANALITICA pedido={} -> demanda registrada para {} producto(s)", event.orderId(), saved);
        return saved;
    }

    @Transactional(readOnly = true)
    public List<DemandSummary> topProducts(int limit) {
        return repository.topProducts(PageRequest.of(0, Math.max(1, Math.min(limit, 50))));
    }
}
