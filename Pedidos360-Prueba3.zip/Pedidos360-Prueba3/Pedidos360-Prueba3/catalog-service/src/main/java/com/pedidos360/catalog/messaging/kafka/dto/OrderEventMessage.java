package com.pedidos360.catalog.messaging.kafka.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

/**
 * DTO tipado del evento de pedido que PRODUCE order-service en el topico de pedidos y CONSUME catalog-service.
 * Es la copia "del lado consumidor" del contrato (no se comparte codigo entre microservicios).
 * Tipos: "PedidoCreado" y "PedidoEstadoCambiado". ignoreUnknown = true tolera campos nuevos del productor.
 */
@JsonIgnoreProperties(ignoreUnknown = true)
public record OrderEventMessage(
        @NotBlank String eventId,
        @NotBlank String type,
        int version,
        Instant occurredAt,
        @NotNull Long orderId,
        String customerId,
        String customerEmail,
        String previousStatus,
        @NotBlank String status,
        BigDecimal total,
        @Valid List<Item> items) {

    public static final String TYPE_CREATED = "PedidoCreado";

    @JsonIgnoreProperties(ignoreUnknown = true)
    public record Item(
            @NotNull Long productId,
            String productName,
            @NotNull @Positive Integer quantity,
            BigDecimal unitPrice) {
    }
}
