package com.pedidos360.catalog.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pedidos360.catalog.messaging.kafka.support.NonRecoverableEventException;
import com.pedidos360.catalog.messaging.StockAlertEvent;
import com.pedidos360.catalog.messaging.kafka.dto.OrderEventMessage;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.common.TopicPartition;
import org.apache.kafka.common.serialization.ByteArraySerializer;
import org.apache.kafka.common.serialization.Serializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.core.DefaultKafkaProducerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.kafka.core.ProducerFactory;
import org.springframework.kafka.listener.ConsumerRecordRecoverer;
import org.springframework.kafka.listener.DeadLetterPublishingRecoverer;
import org.springframework.kafka.listener.DefaultErrorHandler;
import org.springframework.kafka.support.ExponentialBackOffWithMaxRetries;
import org.springframework.kafka.support.serializer.DelegatingByTypeSerializer;
import org.springframework.kafka.support.serializer.JsonSerializer;

import java.util.HashMap;
import java.util.Map;

/**
 * Configuracion del CLIENTE Kafka (productor + manejo de errores del consumidor).
 *  - Las propiedades (bootstrap servers, acks, idempotencia, consumer groups, deserializers...) estan en
 *    application.yml bajo spring.kafka.*  -> se leen de variables de entorno.
 *  - Serializacion: clave String, valor JSON (DTO tipados). Se usa el ObjectMapper de Spring (fechas ISO-8601).
 *  - Errores del consumidor: reintentos con backoff exponencial y, al agotarse, el mensaje va al Dead Letter Topic.
 */
@Configuration
@ConditionalOnProperty(prefix = "pedidos360.kafka", name = "enabled", havingValue = "true", matchIfMissing = true)
public class KafkaClientConfig {

    private static final Logger log = LoggerFactory.getLogger(KafkaClientConfig.class);

    @Bean
    public ProducerFactory<String, Object> kafkaProducerFactory(KafkaProperties kafkaProperties, ObjectMapper objectMapper) {
        Map<String, Object> config = kafkaProperties.buildProducerProperties(null);

        JsonSerializer<Object> json = new JsonSerializer<>(objectMapper);
        json.setAddTypeInfo(false); // el consumidor usa su propio DTO: no se acopla por nombre de clase

        Map<Class<?>, Serializer<?>> delegates = new HashMap<>();
        delegates.put(StockAlertEvent.class, json);
        delegates.put(OrderEventMessage.class, json);
        delegates.put(byte[].class, new ByteArraySerializer()); // mensajes ilegibles que van al DLT

        return new DefaultKafkaProducerFactory<>(config, new StringSerializer(), new DelegatingByTypeSerializer(delegates));
    }

    @Bean
    public KafkaTemplate<String, Object> kafkaTemplate(ProducerFactory<String, Object> kafkaProducerFactory) {
        return new KafkaTemplate<>(kafkaProducerFactory);
    }

    /**
     * Manejo de errores de TODOS los @KafkaListener (Spring Boot lo engancha solo al container factory):
     *  1) validacion/JSON invalido (NonRecoverableEventException, DeserializationException) -> DLT sin reintentos
     *  2) error recuperable (BD caida, etc.) -> reintentos con backoff exponencial
     *  3) reintentos agotados -> Dead Letter Topic + log de error con topico/particion/offset
     */
    @Bean
    public DefaultErrorHandler kafkaErrorHandler(KafkaTemplate<String, Object> kafkaTemplate, KafkaNamesProperties names) {
        DeadLetterPublishingRecoverer deadLetter = new DeadLetterPublishingRecoverer(kafkaTemplate,
                (record, ex) -> new TopicPartition(names.topics().dlt(), -1));

        ConsumerRecordRecoverer recoverer = (ConsumerRecord<?, ?> record, Exception ex) -> {
            log.error("DLT <- mensaje descartado origen={}-{}@{} key={} causa={}",
                    record.topic(), record.partition(), record.offset(), record.key(), rootMessage(ex));
            deadLetter.accept(record, ex);
        };

        KafkaNamesProperties.Retry retry = names.retry();
        ExponentialBackOffWithMaxRetries backOff = new ExponentialBackOffWithMaxRetries(Math.max(0, retry.maxAttempts() - 1));
        backOff.setInitialInterval(retry.initialBackoffMs());
        backOff.setMultiplier(retry.multiplier());
        backOff.setMaxInterval(retry.maxBackoffMs());

        DefaultErrorHandler handler = new DefaultErrorHandler(recoverer, backOff);
        handler.addNotRetryableExceptions(NonRecoverableEventException.class);
        return handler;
    }

    private static String rootMessage(Throwable t) {
        Throwable cur = t;
        while (cur.getCause() != null) {
            cur = cur.getCause();
        }
        return cur.getClass().getSimpleName() + ": " + cur.getMessage();
    }
}
