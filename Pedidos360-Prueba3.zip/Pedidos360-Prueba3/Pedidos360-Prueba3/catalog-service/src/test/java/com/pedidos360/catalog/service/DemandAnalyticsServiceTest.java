package com.pedidos360.catalog.service;

import com.pedidos360.catalog.messaging.kafka.dto.OrderEventMessage;
import com.pedidos360.catalog.model.ProductDemand;
import com.pedidos360.catalog.repository.ProductDemandRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyLong;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

/** La logica de analitica no depende de Kafka: se prueba con un repositorio simulado. */
class DemandAnalyticsServiceTest {

    private ProductDemandRepository repository;
    private DemandAnalyticsService service;

    @BeforeEach
    void setUp() {
        repository = mock(ProductDemandRepository.class);
        service = new DemandAnalyticsService(repository);
    }

    private OrderEventMessage event(String type, List<OrderEventMessage.Item> items) {
        return new OrderEventMessage("evt-1", type, 1, Instant.now(), 10L, "c1", "a@b.cl",
                null, "CREADO", BigDecimal.TEN, items);
    }

    @Test
    void createdOrderRegistersDemandPerItem() {
        var items = List.of(new OrderEventMessage.Item(1L, "Teclado", 2, BigDecimal.ONE),
                new OrderEventMessage.Item(2L, "Mouse", 1, BigDecimal.ONE));
        when(repository.existsByEventIdAndProductId(anyString(), anyLong())).thenReturn(false);

        assertEquals(2, service.record(event(OrderEventMessage.TYPE_CREATED, items)));

        ArgumentCaptor<ProductDemand> captor = ArgumentCaptor.forClass(ProductDemand.class);
        verify(repository, org.mockito.Mockito.times(2)).save(captor.capture());
        assertEquals(2, captor.getAllValues().get(0).getQuantity());
        assertEquals("evt-1", captor.getAllValues().get(0).getEventId());
    }

    @Test
    void duplicatedEventIsNotCountedTwice() {
        var items = List.of(new OrderEventMessage.Item(1L, "Teclado", 2, BigDecimal.ONE));
        when(repository.existsByEventIdAndProductId(eq("evt-1"), eq(1L))).thenReturn(true);

        assertEquals(0, service.record(event(OrderEventMessage.TYPE_CREATED, items)));
        verify(repository, never()).save(any());
    }

    @Test
    void statusChangeEventsAreIgnored() {
        var items = List.of(new OrderEventMessage.Item(1L, "Teclado", 2, BigDecimal.ONE));
        assertEquals(0, service.record(event("PedidoEstadoCambiado", items)));
        verify(repository, never()).save(any());
    }
}
