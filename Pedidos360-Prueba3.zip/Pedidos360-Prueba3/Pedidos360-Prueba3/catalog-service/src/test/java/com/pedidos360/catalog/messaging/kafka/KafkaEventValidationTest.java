package com.pedidos360.catalog.messaging.kafka;

import com.pedidos360.catalog.messaging.kafka.dto.OrderEventMessage;
import com.pedidos360.catalog.messaging.kafka.support.KafkaEventValidator;
import com.pedidos360.catalog.messaging.kafka.support.NonRecoverableEventException;
import jakarta.validation.Validation;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertSame;
import static org.junit.jupiter.api.Assertions.assertThrows;

/** Un evento invalido debe rechazarse como "no recuperable" (va directo al Dead Letter Topic). */
class KafkaEventValidationTest {

    private final KafkaEventValidator validator =
            new KafkaEventValidator(Validation.buildDefaultValidatorFactory().getValidator());

    @Test
    void validEventPasses() {
        var event = new OrderEventMessage("e1", "PedidoCreado", 1, Instant.now(), 5L, "c", "a@b.cl", null, "CREADO",
                BigDecimal.TEN, List.of(new OrderEventMessage.Item(1L, "X", 1, BigDecimal.ONE)));
        assertSame(event, validator.requireValid(event));
    }

    @Test
    void missingRequiredFieldsAreRejected() {
        var event = new OrderEventMessage(null, "PedidoCreado", 1, Instant.now(), null, "c", "a@b.cl", null, "CREADO",
                BigDecimal.TEN, List.of());
        assertThrows(NonRecoverableEventException.class, () -> validator.requireValid(event));
    }

    @Test
    void invalidItemQuantityIsRejected() {
        var event = new OrderEventMessage("e1", "PedidoCreado", 1, Instant.now(), 5L, "c", "a@b.cl", null, "CREADO",
                BigDecimal.TEN, List.of(new OrderEventMessage.Item(1L, "X", 0, BigDecimal.ONE)));
        assertThrows(NonRecoverableEventException.class, () -> validator.requireValid(event));
    }

    @Test
    void nullEventIsRejected() {
        assertThrows(NonRecoverableEventException.class, () -> validator.requireValid(null));
    }
}
